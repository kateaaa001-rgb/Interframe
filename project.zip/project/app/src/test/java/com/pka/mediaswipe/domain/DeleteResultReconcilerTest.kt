package com.pka.mediaswipe.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DeleteResultReconcilerTest {
    @Test
    fun cancelledAuthorizationNeverReportsDeletionSuccess() {
        val uris = listOf("content://media/1", "content://media/2")

        val result = DeleteResultReconciler.reconcile(
            authorized = false,
            requestedUris = uris,
            availability = uris.associateWith { UriAvailability.MISSING },
        )

        assertTrue(result.deletedUris.isEmpty())
        assertEquals(2, result.failures.size)
        assertTrue(result.failures.all { it.reason == DeleteFailureReason.USER_CANCELLED })
    }

    @Test
    fun partialSuccessKeepsOnlyVerifiedDeletions() {
        val deleted = "content://media/1"
        val stillPresent = "content://media/2"
        val accessLost = "content://media/3"

        val result = DeleteResultReconciler.reconcile(
            authorized = true,
            requestedUris = listOf(deleted, stillPresent, accessLost),
            availability = mapOf(
                deleted to UriAvailability.MISSING,
                stillPresent to UriAvailability.PRESENT,
                accessLost to UriAvailability.ACCESS_LOST,
            ),
        )

        assertEquals(setOf(deleted), result.deletedUris)
        assertEquals(2, result.failures.size)
        assertEquals(
            DeleteFailureReason.MEDIA_STILL_PRESENT,
            result.failures.single { it.uri == stillPresent }.reason,
        )
        assertEquals(
            DeleteFailureReason.ACCESS_LOST,
            result.failures.single { it.uri == accessLost }.reason,
        )
    }

    @Test
    fun unknownAvailabilityIsTreatedAsFailure() {
        val uri = "content://media/unknown"

        val result = DeleteResultReconciler.reconcile(
            authorized = true,
            requestedUris = listOf(uri),
            availability = emptyMap(),
        )

        assertTrue(result.deletedUris.isEmpty())
        assertEquals(DeleteFailureReason.ACCESS_LOST, result.failures.single().reason)
    }
}
