package com.pka.mediaswipe.domain

import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class MediaRandomizerTest {
    @Test
    fun shuffle_preservesEveryItemAndRemovesDuplicateUris() {
        val input = (1L..2_000L).map(::media) +
            (1L..10L).map(::media)

        val result = MediaRandomizer.shuffle(input, Random(42))

        assertEquals(2_000, result.size)
        assertEquals(input.map { it.uri }.toSet(), result.map { it.uri }.toSet())
    }

    @Test
    fun shuffle_isDeterministicForASeed() {
        val input = (1L..120L).map(::media)

        val first = MediaRandomizer.shuffle(input, Random(7))
        val second = MediaRandomizer.shuffle(input, Random(7))

        assertEquals(first.map { it.uri }, second.map { it.uri })
    }

    @Test
    fun shuffle_usesRandomOrderForTypicalSeeds() {
        val input = (1L..120L).map(::media)

        val first = MediaRandomizer.shuffle(input, Random(7))
        val second = MediaRandomizer.shuffle(input, Random(9))

        assertNotEquals(first.map { it.uri }, second.map { it.uri })
    }

    @Test
    fun shuffle_handlesZeroAndOneItemLibraries() {
        assertEquals(emptyList<MediaInfo>(), MediaRandomizer.shuffle(emptyList()))
        assertEquals(listOf(media(1)), MediaRandomizer.shuffle(listOf(media(1))))
    }

    private fun media(id: Long): MediaInfo = MediaInfo(
        id = id,
        uri = "content://media/external/images/media/$id",
        mimeType = "image/jpeg",
        displayName = "$id.jpg",
        sizeBytes = 1_000,
        modifiedTime = id,
        durationMs = null,
        isVideo = false,
    )
}
