package com.pka.mediaswipe.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class SessionDecisionLedgerTest {
    @Test
    fun allKeepSessionFinishesEachBoundaryWithoutConfirmation() {
        listOf(0, 1, 49, 50, 51, 100, 101).forEach { total ->
            var ledger = SessionDecisionLedger(total = total)
            while (ledger.currentIndex < ledger.total) {
                ledger = ledger.record(SwipeDecision.KEEP)
                if (ledger.atBatchBoundary) {
                    assertFalse(ledger.requiresConfirmation)
                    val finished = ledger.finishResolvedBatch()
                    assertNotNull("Expected batch to finish for total=$total", finished)
                    ledger = finished!!
                }
            }
            assertEquals(total, ledger.currentIndex)
            assertEquals(total, ledger.batchStart)
        }
    }

    @Test
    fun deleteAtFiftiethItemRequiresConfirmationAndFinalizesOnlyAfterOutcome() {
        var ledger = SessionDecisionLedger(total = 51)
        repeat(49) { ledger = ledger.record(SwipeDecision.KEEP) }
        ledger = ledger.record(SwipeDecision.DELETE)

        assertTrue(ledger.atBatchBoundary)
        assertTrue(ledger.requiresConfirmation)
        assertEquals(listOf(49), ledger.pendingDeletePositions)
        assertNull(ledger.finishResolvedBatch())

        val resolved = ledger.markOutcome(deletedPositions = setOf(49))
        assertFalse(resolved.requiresConfirmation)
        val nextBatch = resolved.finishResolvedBatch()
        assertEquals(50, nextBatch?.batchStart)

        val finalLedger = nextBatch!!.record(SwipeDecision.KEEP)
        assertEquals(51, finalLedger.currentIndex)
        assertTrue(finalLedger.atBatchBoundary)
        assertFalse(finalLedger.requiresConfirmation)
        assertEquals(51, finalLedger.finishResolvedBatch()?.batchStart)
    }

    @Test
    fun favoriteAtBoundaryIsTrackedSeparatelyFromDeletes() {
        var ledger = SessionDecisionLedger(total = 50)
        repeat(49) { ledger = ledger.record(SwipeDecision.KEEP) }
        ledger = ledger.record(SwipeDecision.FAVORITE)

        assertTrue(ledger.pendingDeletePositions.isEmpty())
        assertEquals(listOf(49), ledger.pendingFavoritePositions)
        assertTrue(ledger.requiresConfirmation)

        val resolved = ledger.markOutcome(favoriteSavedPositions = setOf(49))
        assertTrue(resolved.requiresConfirmation.not())
        assertEquals(50, resolved.finishResolvedBatch()?.batchStart)
    }

    @Test
    fun undoRestoresPreviousMediaAndRemovesItsPendingMark() {
        var ledger = SessionDecisionLedger(total = 10)
        repeat(4) { ledger = ledger.record(SwipeDecision.KEEP) }
        ledger = ledger.record(SwipeDecision.DELETE)
        assertEquals(5, ledger.currentIndex)
        assertEquals(listOf(4), ledger.pendingDeletePositions)

        val undone = ledger.undoLast()
        assertNotNull(undone)
        assertEquals(4, undone!!.currentIndex)
        assertTrue(undone.pendingDeletePositions.isEmpty())

        val reRecordedFavorite = undone.record(SwipeDecision.FAVORITE)
        assertTrue(reRecordedFavorite.pendingDeletePositions.isEmpty())
        assertEquals(listOf(4), reRecordedFavorite.pendingFavoritePositions)
    }

    @Test
    fun boundaryCannotBeSkippedWithoutResolvingPendingMarks() {
        var ledger = SessionDecisionLedger(total = 51)
        repeat(49) { ledger = ledger.record(SwipeDecision.KEEP) }
        ledger = ledger.record(SwipeDecision.DELETE)

        try {
            ledger.record(SwipeDecision.KEEP)
            fail("Recording past an unresolved batch boundary must fail")
        } catch (_: IllegalArgumentException) {
            assertTrue(ledger.pendingDeletePositions.isNotEmpty())
        }
    }

    @Test
    fun batchBoundaryAtExactlyHundredItemsStartsAFreshBatch() {
        var ledger = SessionDecisionLedger(total = 101)
        repeat(100) {
            ledger = ledger.record(SwipeDecision.KEEP)
            if (ledger.currentIndex == 50) {
                ledger = ledger.finishResolvedBatch()!!
            }
        }

        assertTrue(ledger.atBatchBoundary)
        val finished = ledger.finishResolvedBatch()
        assertEquals(100, finished?.batchStart)
        assertEquals(1, finished?.batchSize)

        val last = finished!!.record(SwipeDecision.KEEP)
        assertEquals(101, last.finishResolvedBatch()?.batchStart)
    }
}
