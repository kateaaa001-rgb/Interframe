package com.pka.mediaswipe.domain

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BatchSelectionPolicyTest {
    @Test
    fun deleteOnlyDoesNotExecuteFavorites() {
        val selection = BatchSelection(deleteSelected = true)

        assertTrue(
            BatchSelectionPolicy.executeDelete(selection, hasPendingDeletes = true),
        )
        assertFalse(
            BatchSelectionPolicy.executeFavorite(selection, hasPendingFavorites = true),
        )
    }

    @Test
    fun favoriteOnlyDoesNotExecuteDeletes() {
        val selection = BatchSelection(favoriteSelected = true)

        assertFalse(
            BatchSelectionPolicy.executeDelete(selection, hasPendingDeletes = true),
        )
        assertTrue(
            BatchSelectionPolicy.executeFavorite(selection, hasPendingFavorites = true),
        )
    }

    @Test
    fun confirmRequiresAtLeastOneAvailableExplicitSelection() {
        assertFalse(
            BatchSelectionPolicy.canConfirm(
                BatchSelection(),
                hasPendingDeletes = true,
                hasPendingFavorites = true,
            ),
        )
        assertFalse(
            BatchSelectionPolicy.canConfirm(
                BatchSelection(deleteSelected = true),
                hasPendingDeletes = false,
                hasPendingFavorites = true,
            ),
        )
        assertTrue(
            BatchSelectionPolicy.canConfirm(
                BatchSelection(favoriteSelected = true),
                hasPendingDeletes = true,
                hasPendingFavorites = true,
            ),
        )
    }
}
