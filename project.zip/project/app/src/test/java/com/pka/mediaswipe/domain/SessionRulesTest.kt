package com.pka.mediaswipe.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SessionRulesTest {
    @Test
    fun batchSizes_matchRequiredBoundaries() {
        assertEquals(0, SessionRules.batchSize(batchStart = 0, total = 0))
        assertEquals(1, SessionRules.batchSize(batchStart = 0, total = 1))
        assertEquals(49, SessionRules.batchSize(batchStart = 0, total = 49))
        assertEquals(50, SessionRules.batchSize(batchStart = 0, total = 50))
        assertEquals(50, SessionRules.batchSize(batchStart = 0, total = 51))
        assertEquals(1, SessionRules.batchSize(batchStart = 50, total = 51))
        assertEquals(50, SessionRules.batchSize(batchStart = 0, total = 100))
        assertEquals(50, SessionRules.batchSize(batchStart = 50, total = 100))
        assertEquals(50, SessionRules.batchSize(batchStart = 0, total = 101))
        assertEquals(50, SessionRules.batchSize(batchStart = 50, total = 101))
        assertEquals(1, SessionRules.batchSize(batchStart = 100, total = 101))
    }

    @Test
    fun boundaries_onlyOccurAtFiftyOrAtTheEnd() {
        assertFalse(SessionRules.isBatchBoundary(reviewed = 0, total = 51))
        assertFalse(SessionRules.isBatchBoundary(reviewed = 49, total = 51))
        assertTrue(SessionRules.isBatchBoundary(reviewed = 50, total = 51))
        assertFalse(SessionRules.isBatchBoundary(reviewed = 51, total = 101))
        assertTrue(SessionRules.isBatchBoundary(reviewed = 100, total = 101))
        assertTrue(SessionRules.isBatchBoundary(reviewed = 101, total = 101))
        assertTrue(SessionRules.isBatchBoundary(reviewed = 49, total = 49))
    }

    @Test
    fun keepsOnlyNeverRequireConfirmation() {
        val decisions = List(50) { SwipeDecision.KEEP }

        assertFalse(SessionRules.requiresConfirmation(decisions))
    }

    @Test
    fun deleteOrFavoriteRequiresConfirmation() {
        assertTrue(
            SessionRules.requiresConfirmation(
                List(49) { SwipeDecision.KEEP } + SwipeDecision.DELETE,
            ),
        )
        assertTrue(
            SessionRules.requiresConfirmation(
                List(49) { SwipeDecision.KEEP } + SwipeDecision.FAVORITE,
            ),
        )
    }

    @Test
    fun undoIsBlockedAfterSubmittedActionsOrBeforeAnyDecision() {
        assertFalse(SessionRules.canUndo(reviewed = 0, batchStart = 0, batchLocked = false))
        assertTrue(SessionRules.canUndo(reviewed = 1, batchStart = 0, batchLocked = false))
        assertFalse(SessionRules.canUndo(reviewed = 1, batchStart = 0, batchLocked = true))
        assertFalse(SessionRules.canUndo(reviewed = 50, batchStart = 50, batchLocked = false))
    }

    @Test
    fun resetProgressCreatesAtMostOneFiftyItemBatch() {
        assertEquals(0, SessionRules.resetBatchSize(0))
        assertEquals(1, SessionRules.resetBatchSize(1))
        assertEquals(50, SessionRules.resetBatchSize(50))
        assertEquals(50, SessionRules.resetBatchSize(51))
        assertEquals(50, SessionRules.resetBatchSize(100))
    }
}
