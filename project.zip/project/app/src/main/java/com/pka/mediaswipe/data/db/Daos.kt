package com.pka.mediaswipe.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.pka.mediaswipe.domain.SessionStats
import com.pka.mediaswipe.domain.SessionStatus
import com.pka.mediaswipe.domain.SwipeDecision
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites ORDER BY addedAt DESC")
    fun observeAll(): Flow<List<FavoriteEntity>>

    @Query("SELECT COUNT(*) FROM favorites")
    fun observeCount(): Flow<Int>

    @Query("SELECT uri FROM favorites")
    suspend fun getAllUris(): List<String>

    @Query("SELECT * FROM favorites ORDER BY addedAt DESC")
    suspend fun getAll(): List<FavoriteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<FavoriteEntity>)

    @Query("DELETE FROM favorites WHERE uri = :uri")
    suspend fun deleteByUri(uri: String)

    @Query("DELETE FROM favorites WHERE uri IN (:uris)")
    suspend fun deleteByUris(uris: List<String>)
}

@Dao
interface SessionDao {
    @Query("SELECT * FROM cleaning_sessions WHERE status = 'ACTIVE' ORDER BY updatedAt DESC LIMIT 1")
    fun observeActive(): Flow<SessionEntity?>

    @Query("SELECT * FROM cleaning_sessions WHERE status = 'ACTIVE' ORDER BY updatedAt DESC LIMIT 1")
    suspend fun getActive(): SessionEntity?

    @Query("SELECT * FROM cleaning_sessions WHERE id = :sessionId")
    suspend fun getById(sessionId: String): SessionEntity?

    @Query("SELECT * FROM session_items WHERE sessionId = :sessionId ORDER BY position")
    suspend fun getItems(sessionId: String): List<SessionItemEntity>

    @Query(
        """
        SELECT
            COALESCE(SUM(CASE WHEN decision IN ('KEEP', 'FAILED_SKIPPED') THEN 1 ELSE 0 END), 0) AS kept,
            COALESCE(SUM(CASE WHEN decision = 'DELETED' THEN 1 ELSE 0 END), 0) AS deleted,
            COALESCE(SUM(CASE WHEN decision = 'FAVORITE_SAVED' THEN 1 ELSE 0 END), 0) AS favorited
        FROM session_items
        WHERE sessionId = :sessionId
        """,
    )
    suspend fun getStats(sessionId: String): SessionStats

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSession(session: SessionEntity)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertItems(items: List<SessionItemEntity>)

    @Transaction
    suspend fun createSession(session: SessionEntity, items: List<SessionItemEntity>) {
        upsertSession(session)
        insertItems(items)
    }

    @Query(
        """
        UPDATE cleaning_sessions
        SET currentIndex = :currentIndex, updatedAt = :updatedAt
        WHERE id = :sessionId
        """,
    )
    suspend fun updateProgress(sessionId: String, currentIndex: Int, updatedAt: Long)

    @Query(
        """
        UPDATE cleaning_sessions
        SET activeBatchStart = :batchStart, batchLocked = :locked, updatedAt = :updatedAt
        WHERE id = :sessionId
        """,
    )
    suspend fun updateBatchState(sessionId: String, batchStart: Int, locked: Boolean, updatedAt: Long)

    @Query(
        """
        UPDATE cleaning_sessions
        SET status = 'COMPLETED', updatedAt = :updatedAt
        WHERE id = :sessionId
        """,
    )
    suspend fun completeSession(sessionId: String, updatedAt: Long)

    @Query(
        """
        UPDATE cleaning_sessions
        SET activeBatchStart = :batchStart,
            batchLocked = 0,
            status = :status,
            updatedAt = :updatedAt
        WHERE id = :sessionId
        """,
    )
    suspend fun finalizeBatch(
        sessionId: String,
        batchStart: Int,
        status: SessionStatus,
        updatedAt: Long,
    )

    @Query(
        """
        UPDATE session_items
        SET decision = :decision
        WHERE sessionId = :sessionId AND position = :position
        """,
    )
    suspend fun updateDecision(sessionId: String, position: Int, decision: SwipeDecision)
}

@Dao
interface SettingsDao {
    @Query("SELECT * FROM app_settings WHERE id = 1")
    fun observe(): Flow<SettingsEntity?>

    @Query("SELECT * FROM app_settings WHERE id = 1")
    suspend fun get(): SettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(settings: SettingsEntity)
}
