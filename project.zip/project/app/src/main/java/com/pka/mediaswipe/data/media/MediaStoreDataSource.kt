package com.pka.mediaswipe.data.media

import android.app.PendingIntent
import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.core.net.toUri
import com.pka.mediaswipe.domain.MediaInfo
import com.pka.mediaswipe.domain.UriAvailability
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MediaStoreDataSource(context: Context) {
    private val resolver: ContentResolver = context.applicationContext.contentResolver

    suspend fun queryAccessibleMedia(): List<MediaInfo> = withContext(Dispatchers.IO) {
        val collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.Files.FileColumns.MEDIA_TYPE,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_MODIFIED,
            MediaStore.MediaColumns.DURATION,
        )
        val selection = "${MediaStore.Files.FileColumns.MEDIA_TYPE} IN (?, ?)"
        val args = arrayOf(
            MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
            MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString(),
        )
        val result = mutableListOf<MediaInfo>()

        val cursor = resolver.query(
            collection,
            projection,
            selection,
            args,
            "${MediaStore.MediaColumns.DATE_MODIFIED} DESC",
        ) ?: return@withContext emptyList()
        try {
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val typeColumn = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE)
            val mimeColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
            val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val modifiedColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)
            val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DURATION)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idColumn)
                val isVideo = cursor.getInt(typeColumn) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                val mimeType = cursor.getString(mimeColumn)
                    ?: if (isVideo) "video/*" else "image/*"
                val baseUri = if (isVideo) {
                    MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                } else {
                    MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                }
                result += MediaInfo(
                    id = id,
                    uri = ContentUris.withAppendedId(baseUri, id).toString(),
                    mimeType = mimeType,
                    displayName = cursor.getString(nameColumn) ?: "未命名媒体",
                    sizeBytes = cursor.getLong(sizeColumn),
                    modifiedTime = cursor.getLong(modifiedColumn) * 1_000L,
                    durationMs = cursor.getLong(durationColumn).takeIf { it > 0 && isVideo },
                    isVideo = isVideo,
                )
            }
        } finally {
            cursor.close()
        }
        result
    }

    fun createDeleteRequest(uris: List<String>): PendingIntent {
        require(uris.isNotEmpty()) { "删除请求不能为空" }
        return MediaStore.createDeleteRequest(resolver, uris.map(Uri::parse))
    }

    suspend fun availability(uri: String): UriAvailability = withContext(Dispatchers.IO) {
        try {
            resolver.query(
                uri.toUri(),
                arrayOf(MediaStore.MediaColumns._ID),
                null,
                null,
                null,
            )?.use { cursor ->
                if (cursor.moveToFirst()) UriAvailability.PRESENT else UriAvailability.MISSING
            } ?: UriAvailability.MISSING
        } catch (_: SecurityException) {
            UriAvailability.ACCESS_LOST
        } catch (_: Exception) {
            UriAvailability.ACCESS_LOST
        }
    }
}
