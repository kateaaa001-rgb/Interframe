package com.pka.mediaswipe.data.media

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

data class MediaPermissionSnapshot(
    val hasFullAccess: Boolean = false,
    val hasPartialAccess: Boolean = false,
    val canReadMedia: Boolean = false,
) {
    val isDenied: Boolean get() = !canReadMedia
}

object MediaPermissions {
    fun requiredPermissions(): Array<String> = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE -> arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED,
        )
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VIDEO,
        )
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    fun snapshot(context: Context): MediaPermissionSnapshot {
        fun granted(permission: String): Boolean =
            ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

        return when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE -> {
                val images = granted(Manifest.permission.READ_MEDIA_IMAGES)
                val videos = granted(Manifest.permission.READ_MEDIA_VIDEO)
                val selected = granted(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
                val full = images && videos
                val partial = !full && selected
                MediaPermissionSnapshot(
                    hasFullAccess = full,
                    hasPartialAccess = partial,
                    canReadMedia = full || partial || images || videos,
                )
            }
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> {
                val images = granted(Manifest.permission.READ_MEDIA_IMAGES)
                val videos = granted(Manifest.permission.READ_MEDIA_VIDEO)
                val full = images && videos
                MediaPermissionSnapshot(
                    hasFullAccess = full,
                    hasPartialAccess = !full && (images || videos),
                    canReadMedia = images || videos,
                )
            }
            else -> {
                val granted = granted(Manifest.permission.READ_EXTERNAL_STORAGE)
                MediaPermissionSnapshot(
                    hasFullAccess = granted,
                    hasPartialAccess = false,
                    canReadMedia = granted,
                )
            }
        }
    }
}
