package com.pka.mediaswipe.data.repository

import androidx.room.withTransaction
import com.pka.mediaswipe.data.db.FavoriteEntity
import com.pka.mediaswipe.data.db.MediaSwipeDatabase
import com.pka.mediaswipe.data.db.SessionEntity
import com.pka.mediaswipe.data.db.SessionItemEntity
import com.pka.mediaswipe.data.media.MediaStoreDataSource
import com.pka.mediaswipe.domain.MediaInfo
import com.pka.mediaswipe.domain.MediaRandomizer
import com.pka.mediaswipe.domain.BATCH_SIZE
import com.pka.mediaswipe.domain.SessionRules
import com.pka.mediaswipe.domain.SessionStats
import com.pka.mediaswipe.domain.SessionStatus
import com.pka.mediaswipe.domain.SwipeDecision
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

data class SessionSnapshot(
    val session: SessionEntity,
    val items: List<SessionItemEntity>,
    val stats: SessionStats,
)

class CleaningRepository(
    private val database: MediaSwipeDatabase,
    private val mediaStore: MediaStoreDataSource,
) {
    private val sessionDao = database.sessionDao()
    private val favoriteDao = database.favoriteDao()

    val activeSession: Flow<SessionEntity?> = sessionDao.observeActive()

    suspend fun loadOrCreateSession(): SessionSnapshot? = withContext(Dispatchers.IO) {
        val active = sessionDao.getActive()
        if (active != null) snapshot(active) else createSession()
    }

    suspend fun snapshotOf(sessionId: String): SessionSnapshot? = withContext(Dispatchers.IO) {
        val session = sessionDao.getById(sessionId)
        if (session != null) snapshot(session) else null
    }

    suspend fun applyDecision(sessionId: String, position: Int, decision: SwipeDecision) =
        withContext(Dispatchers.IO) {
            database.withTransaction {
                sessionDao.updateDecision(sessionId, position, decision)
                sessionDao.updateProgress(sessionId, position + 1, now())
            }
        }

    suspend fun undoDecision(sessionId: String, position: Int) = withContext(Dispatchers.IO) {
        database.withTransaction {
            sessionDao.updateDecision(sessionId, position, SwipeDecision.KEEP)
            sessionDao.updateProgress(sessionId, position, now())
        }
    }

    suspend fun setBatchLocked(sessionId: String, locked: Boolean) = withContext(Dispatchers.IO) {
        val session = sessionDao.getById(sessionId) ?: return@withContext
        sessionDao.updateBatchState(sessionId, session.activeBatchStart, locked, now())
    }

    suspend fun setDecisionPositions(
        sessionId: String,
        positions: Collection<Int>,
        decision: SwipeDecision,
    ) = withContext(Dispatchers.IO) {
        database.withTransaction {
            positions.forEach { position ->
                sessionDao.updateDecision(sessionId, position, decision)
            }
        }
    }

    suspend fun saveFavorites(sessionId: String, items: List<SessionItemEntity>) =
        withContext(Dispatchers.IO) {
            if (items.isEmpty()) return@withContext
            val now = now()
            database.withTransaction {
                favoriteDao.upsertAll(
                    items.map {
                        FavoriteEntity(
                            uri = it.uri,
                            mediaId = it.mediaId,
                            mimeType = it.mimeType,
                            displayName = it.displayName,
                            sizeBytes = it.sizeBytes,
                            modifiedTime = it.modifiedTime,
                            durationMs = it.durationMs,
                            isVideo = it.isVideo,
                            addedAt = now,
                        )
                    },
                )
                items.forEach {
                    sessionDao.updateDecision(sessionId, it.position, SwipeDecision.FAVORITE_SAVED)
                }
                val session = sessionDao.getById(sessionId)
                if (session != null) {
                    sessionDao.updateBatchState(sessionId, session.activeBatchStart, true, now)
                }
            }
        }

    suspend fun clearPendingBatchDecisions(sessionId: String) = withContext(Dispatchers.IO) {
        val session = sessionDao.getById(sessionId) ?: return@withContext
        val items = sessionDao.getItems(sessionId)
        database.withTransaction {
            items.asSequence()
                .filter { it.position >= session.activeBatchStart && it.position < session.currentIndex }
                .filter { it.decision == SwipeDecision.DELETE || it.decision == SwipeDecision.FAVORITE }
                .forEach {
                    sessionDao.updateDecision(sessionId, it.position, SwipeDecision.KEEP)
                }
        }
    }

    suspend fun finalizeBatch(sessionId: String): SessionSnapshot? = withContext(Dispatchers.IO) {
        val session = sessionDao.getById(sessionId) ?: return@withContext null
        val nextStatus = if (session.currentIndex >= session.totalCount) {
            SessionStatus.COMPLETED
        } else {
            SessionStatus.ACTIVE
        }
        sessionDao.finalizeBatch(sessionId, session.currentIndex, nextStatus, now())
        snapshotOf(sessionId)
    }

    suspend fun resetActiveSessionToNewBatch(batchLimit: Int = BATCH_SIZE): Boolean =
        withContext(Dispatchers.IO) {
            val active = sessionDao.getActive() ?: return@withContext false
            val favoriteUris = favoriteDao.getAllUris().toSet()
            val accessible = mediaStore.queryAccessibleMedia().filterNot { it.uri in favoriteUris }
            if (accessible.isEmpty()) return@withContext false

            val ordered = MediaRandomizer.shuffle(accessible)
                .take(SessionRules.resetBatchSize(batchLimit.coerceAtLeast(1)))
            val sessionId = UUID.randomUUID().toString()
            val timestamp = now()
            val session = SessionEntity(
                id = sessionId,
                createdAt = timestamp,
                updatedAt = timestamp,
                status = SessionStatus.ACTIVE,
                totalCount = ordered.size,
                currentIndex = 0,
                activeBatchStart = 0,
                batchLocked = false,
            )
            val items = ordered.mapIndexed { index, media ->
                media.toSessionItem(sessionId, index)
            }
            database.withTransaction {
                sessionDao.completeSession(active.id, timestamp)
                sessionDao.createSession(session, items)
            }
            true
        }

    private suspend fun createSession(): SessionSnapshot? {
        val favoriteUris = favoriteDao.getAllUris().toSet()
        val accessible = mediaStore.queryAccessibleMedia().filterNot { it.uri in favoriteUris }
        if (accessible.isEmpty()) return null

        val ordered = MediaRandomizer.shuffle(accessible)
        val sessionId = UUID.randomUUID().toString()
        val timestamp = now()
        val session = SessionEntity(
            id = sessionId,
            createdAt = timestamp,
            updatedAt = timestamp,
            status = SessionStatus.ACTIVE,
            totalCount = ordered.size,
            currentIndex = 0,
            activeBatchStart = 0,
            batchLocked = false,
        )
        val items = ordered.mapIndexed { index, media ->
            media.toSessionItem(sessionId, index)
        }
        sessionDao.createSession(session, items)
        return snapshot(session)
    }

    private suspend fun snapshot(session: SessionEntity): SessionSnapshot = SessionSnapshot(
        session = session,
        items = sessionDao.getItems(session.id),
        stats = sessionDao.getStats(session.id),
    )

    fun currentBatchSize(session: SessionEntity): Int =
        SessionRules.batchSize(session.activeBatchStart, session.totalCount)

    private fun MediaInfo.toSessionItem(sessionId: String, position: Int): SessionItemEntity =
        SessionItemEntity(
            sessionId = sessionId,
            position = position,
            mediaId = id,
            uri = uri,
            mimeType = mimeType,
            displayName = displayName,
            sizeBytes = sizeBytes,
            modifiedTime = modifiedTime,
            durationMs = durationMs,
            isVideo = isVideo,
        )

    private fun now(): Long = System.currentTimeMillis()
}
