package com.pka.mediaswipe.ui.screens

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.pka.mediaswipe.data.db.SessionItemEntity
import com.pka.mediaswipe.domain.BatchSelection
import com.pka.mediaswipe.domain.DeleteFailureReason
import com.pka.mediaswipe.domain.SessionStats
import com.pka.mediaswipe.domain.SwipeDecision
import com.pka.mediaswipe.ui.components.EmptyState
import com.pka.mediaswipe.ui.components.MediaThumbnail
import com.pka.mediaswipe.ui.components.SwipeableMediaCard
import com.pka.mediaswipe.ui.viewmodel.BatchOperationResult
import com.pka.mediaswipe.ui.viewmodel.CleaningEvent
import com.pka.mediaswipe.ui.viewmodel.CleaningPhase
import com.pka.mediaswipe.ui.viewmodel.CleaningUiState
import com.pka.mediaswipe.ui.viewmodel.CleaningViewModel

@Composable
fun CleaningScreen(
    viewModel: CleaningViewModel,
    showSwipeHints: Boolean,
    onExit: () -> Unit,
    onViewFavorites: () -> Unit,
) {
    val state by viewModel.state.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val deleteLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult(),
    ) { result ->
        viewModel.onDeleteAuthorizationResult(result.resultCode == Activity.RESULT_OK)
    }

    LaunchedEffect(viewModel) {
        viewModel.loadOrCreate()
        viewModel.events.collect { event ->
            when (event) {
                is CleaningEvent.LaunchDeleteAuthorization -> {
                    deleteLauncher.launch(
                        IntentSenderRequest.Builder(event.pendingIntent.intentSender).build(),
                    )
                }
            }
        }
    }

    LaunchedEffect(state.error) {
        state.error?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.dismissError()
        }
    }

    BackHandler(onBack = onExit)

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background,
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            when (state.phase) {
                CleaningPhase.LOADING -> LoadingState(onExit = onExit)
                CleaningPhase.EMPTY -> CleaningEmptyState(onExit = onExit)
                CleaningPhase.ERROR -> CleaningErrorState(
                    message = state.error ?: "无法读取清理会话",
                    onExit = onExit,
                )
                CleaningPhase.COMPLETED -> CompletionState(
                    stats = state.stats,
                    onHome = onExit,
                    onViewFavorites = onViewFavorites,
                )
                CleaningPhase.READY -> CleaningReadyContent(
                    state = state,
                    showSwipeHints = showSwipeHints,
                    onSwipe = viewModel::swipe,
                    onUndo = viewModel::undo,
                    onExit = onExit,
                    onOpenBatch = viewModel::openBatchDialog,
                )
            }

            if (state.busy) {
                BusyOverlay(awaitingSystemDelete = state.awaitingSystemDelete)
            }
        }
    }

    if (state.batchDialogVisible) {
        BatchConfirmationDialog(
            state = state,
            onConfirm = viewModel::confirmBatch,
            onDismiss = viewModel::dismissBatchDialog,
            onDiscard = viewModel::requestDiscardMarks,
        )
    }

    if (state.discardDialogVisible) {
        DiscardMarksDialog(
            onConfirm = viewModel::confirmDiscardMarks,
            onDismiss = viewModel::cancelDiscardMarks,
        )
    }

    state.operationResult?.let { result ->
        BatchOperationResultDialog(
            result = result,
            pendingDeletes = state.pendingDeletes.size,
            pendingFavorites = state.pendingFavorites.size,
            onRetryDeletes = viewModel::retryFailedDeletes,
            onRetryFavorites = viewModel::retryFavorites,
            onSkipFailedDeletes = viewModel::skipFailedDeletes,
            onContinue = viewModel::continueAfterOperation,
            onReturnToBatch = viewModel::returnToBatch,
        )
    }
}

@Composable
private fun CleaningReadyContent(
    state: CleaningUiState,
    showSwipeHints: Boolean,
    onSwipe: (SwipeDecision) -> Unit,
    onUndo: () -> Unit,
    onExit: () -> Unit,
    onOpenBatch: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 10.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 2.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onExit) {
                Icon(Icons.Filled.Close, contentDescription = "暂停并返回")
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "第 ${state.positionInBatch} / ${state.currentBatchSize} 项",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                )
                Text(
                    "本会话已审核 ${state.reviewed} / ${state.total}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            TextButton(onClick = onUndo, enabled = state.canUndo) {
                Text("撤销")
            }
        }

        LinearProgressIndicator(
            progress = {
                if (state.total == 0) 0f else state.reviewed.toFloat() / state.total
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .clip(CircleShape),
        )

        Spacer(Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
        ) {
            state.currentItem?.let { item ->
                SwipeableMediaCard(
                    item = item,
                    enabled = state.canSwipe,
                    showHints = showSwipeHints,
                    onSwipe = onSwipe,
                )
            }
        }

        if (state.atBatchBoundary &&
            (state.pendingDeletes.isNotEmpty() || state.pendingFavorites.isNotEmpty())
        ) {
            BatchPendingBanner(
                deleteCount = state.pendingDeletes.size,
                favoriteCount = state.pendingFavorites.size,
                onOpenBatch = onOpenBatch,
                onUndo = onUndo,
                canUndo = state.canUndo,
            )
        } else {
            Text(
                "左滑待删 · 上滑保留 · 右滑收藏",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
            ActionButtons(
                enabled = state.canSwipe,
                onSwipe = onSwipe,
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            PendingCount(
                label = "待删除",
                count = state.pendingDeletes.size,
                color = MaterialTheme.colorScheme.error,
            )
            PendingCount(
                label = "待收藏",
                count = state.pendingFavorites.size,
                color = Color(0xFF3E7250),
            )
        }
    }
}

@Composable
private fun ActionButtons(
    enabled: Boolean,
    onSwipe: (SwipeDecision) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        FilledTonalButton(
            onClick = { onSwipe(SwipeDecision.DELETE) },
            enabled = enabled,
            modifier = Modifier
                .weight(1f)
                .height(54.dp),
            colors = ButtonDefaults.filledTonalButtonColors(
                containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.12f),
                contentColor = MaterialTheme.colorScheme.error,
            ),
        ) {
            Icon(Icons.Filled.Delete, contentDescription = null, modifier = Modifier.size(20.dp))
            Text("删除", modifier = Modifier.padding(start = 5.dp))
        }
        FilledTonalButton(
            onClick = { onSwipe(SwipeDecision.KEEP) },
            enabled = enabled,
            modifier = Modifier
                .weight(1f)
                .height(54.dp),
        ) {
            Icon(Icons.Filled.KeyboardArrowUp, contentDescription = null, modifier = Modifier.size(20.dp))
            Text("保留", modifier = Modifier.padding(start = 5.dp))
        }
        FilledTonalButton(
            onClick = { onSwipe(SwipeDecision.FAVORITE) },
            enabled = enabled,
            modifier = Modifier
                .weight(1f)
                .height(54.dp),
            colors = ButtonDefaults.filledTonalButtonColors(
                containerColor = Color(0xFF3E7250).copy(alpha = 0.13f),
                contentColor = Color(0xFF3E7250),
            ),
        ) {
            Icon(Icons.Filled.FavoriteBorder, contentDescription = null, modifier = Modifier.size(20.dp))
            Text("收藏", modifier = Modifier.padding(start = 5.dp))
        }
    }
}

@Composable
private fun BatchPendingBanner(
    deleteCount: Int,
    favoriteCount: Int,
    onOpenBatch: () -> Unit,
    onUndo: () -> Unit,
    canUndo: Boolean,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f),
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text("本批次已审核完成，标记尚未提交", style = MaterialTheme.typography.titleSmall)
            Text(
                "待删除 $deleteCount 项 · 待收藏 $favoriteCount 项",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onOpenBatch, modifier = Modifier.weight(1f)) {
                    Text("处理本批")
                }
                OutlinedButton(onClick = onUndo, enabled = canUndo) {
                    Text("撤销上一步")
                }
            }
        }
    }
}

@Composable
private fun PendingCount(label: String, count: Int, color: Color) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Surface(
            shape = CircleShape,
            color = color.copy(alpha = 0.13f),
        ) {
            Text(
                text = count.toString(),
                modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp),
                style = MaterialTheme.typography.labelMedium,
                color = color,
            )
        }
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun BatchConfirmationDialog(
    state: CleaningUiState,
    onConfirm: (BatchSelection) -> Unit,
    onDismiss: () -> Unit,
    onDiscard: () -> Unit,
) {
    val deleteCount = state.pendingDeletes.size
    val favoriteCount = state.pendingFavorites.size
    var deleteChecked by remember(state.reviewed, deleteCount, favoriteCount) {
        mutableStateOf(false)
    }
    var favoriteChecked by remember(state.reviewed, deleteCount, favoriteCount) {
        mutableStateOf(false)
    }
    val representatives = remember(state.pendingDeletes, state.pendingFavorites) {
        (state.pendingDeletes + state.pendingFavorites).distinctBy { it.uri }.take(4)
    }
    val canConfirm = (deleteChecked && deleteCount > 0) ||
        (favoriteChecked && favoriteCount > 0)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("本批次审核完成") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (representatives.isNotEmpty()) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(representatives, key = { it.uri }) { item ->
                            MediaThumbnail(
                                uri = item.uri,
                                isVideo = item.isVideo,
                                contentDescription = "待处理媒体预览",
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(RoundedCornerShape(7.dp)),
                            )
                        }
                    }
                }
                if (deleteCount > 0) {
                    SelectionRow(
                        checked = deleteChecked,
                        onCheckedChange = { deleteChecked = it },
                        title = "确认删除 $deleteCount 项",
                        detail = "将通过 Android 系统删除授权流程执行",
                    )
                }
                if (favoriteCount > 0) {
                    SelectionRow(
                        checked = favoriteChecked,
                        onCheckedChange = { favoriteChecked = it },
                        title = "确认收藏 $favoriteCount 项",
                        detail = "只保存本地收藏记录，不修改系统相册标记",
                    )
                }
                HorizontalDivider()
                Text(
                    "未勾选的操作不会执行。你可以只处理删除、只处理收藏，或同时处理两项。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                TextButton(
                    onClick = onDiscard,
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = MaterialTheme.colorScheme.error,
                    ),
                ) {
                    Text("放弃本批标记")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(
                        BatchSelection(
                            deleteSelected = deleteChecked,
                            favoriteSelected = favoriteChecked,
                        ),
                    )
                },
                enabled = canConfirm,
            ) {
                Text("确认执行所选操作")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("暂不处理") }
        },
    )
}

@Composable
private fun SelectionRow(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    title: String,
    detail: String,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.48f))
            .padding(end = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(checked = checked, onCheckedChange = onCheckedChange)
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium)
            Text(
                detail,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun DiscardMarksDialog(
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("确认放弃本批标记？") },
        text = {
            Text(
                "本批尚未执行的删除和收藏标记会被清空，已完成的系统删除与已保存的收藏不会被回滚。",
            )
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                ),
            ) { Text("确认放弃") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("取消") }
        },
    )
}

@Composable
private fun BatchOperationResultDialog(
    result: BatchOperationResult,
    pendingDeletes: Int,
    pendingFavorites: Int,
    onRetryDeletes: () -> Unit,
    onRetryFavorites: () -> Unit,
    onSkipFailedDeletes: () -> Unit,
    onContinue: () -> Unit,
    onReturnToBatch: () -> Unit,
) {
    Dialog(
        onDismissRequest = onReturnToBatch,
        properties = DialogProperties(dismissOnBackPress = true, dismissOnClickOutside = false),
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 4.dp,
        ) {
            Column(
                modifier = Modifier
                    .padding(22.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text("本批操作结果", style = MaterialTheme.typography.titleLarge)
                if (result.favoritesSaved > 0) {
                    Text("已保存收藏：${result.favoritesSaved} 项")
                }
                if (result.favoriteFailures > 0) {
                    Text(
                        "收藏失败：${result.favoriteFailures} 项，记录仍未提交",
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                if (result.deleteAttempted) {
                    Text("已确认删除：${result.deletedCount} 项")
                }
                if (result.deleteFailures.isNotEmpty()) {
                    Text(
                        "删除未完成：${result.deleteFailures.size} 项",
                        color = MaterialTheme.colorScheme.error,
                    )
                    val cancelled = result.deleteFailures.count {
                        it.reason == DeleteFailureReason.USER_CANCELLED
                    }
                    val stillPresent = result.deleteFailures.count {
                        it.reason == DeleteFailureReason.MEDIA_STILL_PRESENT
                    }
                    val accessLost = result.deleteFailures.count {
                        it.reason == DeleteFailureReason.ACCESS_LOST
                    }
                    val requestFailed = result.deleteFailures.count {
                        it.reason == DeleteFailureReason.REQUEST_FAILED
                    }
                    if (cancelled > 0) {
                        Text(
                            "你取消了系统删除授权，这 $cancelled 项没有被删除。",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    if (stillPresent > 0) {
                        Text(
                            "$stillPresent 项在系统中仍可访问，未标记为成功删除。",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    if (accessLost > 0) {
                        Text(
                            "$accessLost 项因权限或访问状态变化无法核验，未标记为成功删除。",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    if (requestFailed > 0) {
                        Text(
                            "$requestFailed 项未能发起系统删除请求。",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                if (pendingDeletes > 0 || pendingFavorites > 0) {
                    Text(
                        "本批仍有待处理项：待删除 $pendingDeletes 项，待收藏 $pendingFavorites 项。",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (!result.hasFailures && pendingDeletes == 0 && pendingFavorites == 0) {
                    Text("所选操作均已明确完成。")
                }

                Spacer(Modifier.height(2.dp))
                if (result.hasFavoriteFailures) {
                    Button(onClick = onRetryFavorites, modifier = Modifier.fillMaxWidth()) {
                        Text("重试收藏")
                    }
                }
                if (result.hasDeleteFailures) {
                    Button(onClick = onRetryDeletes, modifier = Modifier.fillMaxWidth()) {
                        Text("重新尝试删除")
                    }
                    OutlinedButton(
                        onClick = onSkipFailedDeletes,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text("跳过失败项目")
                    }
                    Text(
                        "跳过只会放弃失败或取消的删除标记，不会把未成功删除的项目显示为已删除。",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (!result.hasFavoriteFailures && !result.hasDeleteFailures) {
                    Button(onClick = onContinue, modifier = Modifier.fillMaxWidth()) {
                        Text(
                            if (pendingDeletes > 0 || pendingFavorites > 0) {
                                "继续处理本批"
                            } else {
                                "继续"
                            },
                        )
                    }
                }
                TextButton(
                    onClick = onReturnToBatch,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text("暂不处理，返回本批")
                }
            }
        }
    }
}

@Composable
private fun BusyOverlay(awaitingSystemDelete: Boolean) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.30f)),
        contentAlignment = Alignment.Center,
    ) {
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 4.dp,
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                Text(
                    if (awaitingSystemDelete) "等待 Android 系统删除确认" else "正在保存状态",
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }
    }
}

@Composable
private fun LoadingState(onExit: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
    ) {
        IconButton(
            onClick = onExit,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(8.dp),
        ) {
            Icon(Icons.Filled.Close, contentDescription = "暂停并返回")
        }
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            CircularProgressIndicator()
            Text("正在扫描并随机排序媒体")
            Text(
                "只会读取已授权范围内媒体的元数据，缩略图按需加载。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun CleaningEmptyState(onExit: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(modifier = Modifier.fillMaxWidth()) {
            IconButton(onClick = onExit) {
                Icon(Icons.Filled.Close, contentDescription = "返回")
            }
        }
        EmptyState(
            title = "没有可加入清理队列的媒体",
            detail = "请检查权限范围，或确认媒体是否已收藏、是否仍在系统媒体库中。",
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
        )
        Button(onClick = onExit, modifier = Modifier.padding(20.dp)) {
            Text("返回首页检查权限")
        }
    }
}

@Composable
private fun CleaningErrorState(message: String, onExit: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("无法开始清理", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(
            message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(18.dp))
        Button(onClick = onExit) { Text("返回首页") }
    }
}

@Composable
private fun CompletionState(
    stats: SessionStats,
    onHome: () -> Unit,
    onViewFavorites: () -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(22.dp),
        contentAlignment = Alignment.Center,
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp,
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text("本轮清理完成", style = MaterialTheme.typography.headlineSmall)
                Text(
                    "未删除的项目会保留在相册中，之后的新会话仍可能重新抽到它们。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                ) {
                    CompletionMetric("保留", stats.kept)
                    CompletionMetric("已删除", stats.deleted)
                    CompletionMetric("收藏", stats.favorited)
                }
                Spacer(Modifier.height(4.dp))
                Button(onClick = onHome, modifier = Modifier.fillMaxWidth()) {
                    Text("返回首页")
                }
                OutlinedButton(onClick = onViewFavorites, modifier = Modifier.fillMaxWidth()) {
                    Text("查看本地收藏")
                }
            }
        }
    }
}

@Composable
private fun CompletionMetric(label: String, value: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            value.toString(),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.SemiBold,
        )
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
