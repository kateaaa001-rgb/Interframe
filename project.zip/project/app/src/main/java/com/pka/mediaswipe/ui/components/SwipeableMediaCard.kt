package com.pka.mediaswipe.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector2D
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.pka.mediaswipe.data.db.SessionItemEntity
import com.pka.mediaswipe.domain.SwipeDecision
import java.text.DecimalFormat
import kotlin.math.abs
import kotlin.math.min
import kotlinx.coroutines.launch

private enum class SwipeDirection {
    KEEP,
    DELETE,
    FAVORITE,
}

@Composable
fun SwipeableMediaCard(
    item: SessionItemEntity,
    enabled: Boolean,
    showHints: Boolean,
    onSwipe: (SwipeDecision) -> Unit,
    modifier: Modifier = Modifier,
) {
    val scope = rememberCoroutineScope()
    var cardSize by remember { mutableStateOf(IntSize.Zero) }
    val offset = remember { Animatable(Offset.Zero, Offset.VectorConverter) }
    var animating by remember { mutableStateOf(false) }
    var videoInteracting by remember { mutableStateOf(false) }

    LaunchedEffect(item.uri) {
        offset.snapTo(Offset.Zero)
        animating = false
        videoInteracting = false
    }

    fun screenshotThresholds(): Pair<Float, Float> {
        val width = cardSize.width.toFloat().coerceAtLeast(1f)
        val height = cardSize.height.toFloat().coerceAtLeast(1f)
        return width * 0.22f to height * 0.17f
    }

    fun animateAction(direction: SwipeDirection) {
        if (!enabled || animating) return
        animating = true
        val width = cardSize.width.toFloat().coerceAtLeast(1f)
        val height = cardSize.height.toFloat().coerceAtLeast(1f)
        scope.launch {
            val target = when (direction) {
                SwipeDirection.KEEP -> Offset(0f, -height * 1.18f)
                SwipeDirection.DELETE -> Offset(-width * 1.2f, 0f)
                SwipeDirection.FAVORITE -> Offset(width * 1.2f, 0f)
            }
            offset.animateTo(target, tween(190))
            onSwipe(
                when (direction) {
                    SwipeDirection.KEEP -> SwipeDecision.KEEP
                    SwipeDirection.DELETE -> SwipeDecision.DELETE
                    SwipeDirection.FAVORITE -> SwipeDecision.FAVORITE
                },
            )
            offset.snapTo(Offset.Zero)
            animating = false
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 10.dp)
            .onSizeChanged { cardSize = it }
            .pointerInput(item.uri, enabled, videoInteracting) {
                if (!enabled || videoInteracting) return@pointerInput
                detectDragGestures(
                    onDragEnd = {
                        val (horizontalThreshold, verticalThreshold) = screenshotThresholds()
                        val current = offset.value
                        val horizontal = abs(current.x) > horizontalThreshold &&
                            abs(current.x) > abs(current.y)
                        val vertical = -current.y > verticalThreshold &&
                            abs(current.y) > abs(current.x)
                        when {
                            horizontal && current.x < 0 -> animateAction(SwipeDirection.DELETE)
                            horizontal && current.x > 0 -> animateAction(SwipeDirection.FAVORITE)
                            vertical -> animateAction(SwipeDirection.KEEP)
                            else -> scope.launch {
                                offset.animateTo(Offset.Zero, tween(180))
                            }
                        }
                    },
                    onDrag = { change, amount ->
                        if (!animating) {
                                change.consume()
                            scope.launch {
                                val width = cardSize.width.toFloat().coerceAtLeast(1f)
                                val height = cardSize.height.toFloat().coerceAtLeast(1f)
                                offset.snapTo(
                                    Offset(
                                        x = (offset.value.x + amount.x)
                                            .coerceIn(-width * 0.95f, width * 0.95f),
                                        y = (offset.value.y + amount.y)
                                            .coerceIn(-height * 0.95f, height * 0.20f),
                                    ),
                                )
                            }
                        }
                    },
                    onDragCancel = {
                        scope.launch { offset.animateTo(Offset.Zero, tween(180)) }
                    },
                )
            },
    ) {
        val currentOffset = offset.value
        val width = cardSize.width.toFloat().coerceAtLeast(1f)
        val rotation = (currentOffset.x / width) * 7f
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(
                1.dp,
                MaterialTheme.colorScheme.outline.copy(alpha = 0.18f),
            ),
            shadowElevation = 2.dp,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    translationX = currentOffset.x
                    translationY = currentOffset.y
                    rotationZ = rotation
                },
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                MediaPreview(
                    uri = item.uri,
                    isVideo = item.isVideo,
                    contentDescription = if (item.isVideo) {
                        "正在预览视频 ${item.displayName}"
                    } else {
                        "正在预览照片 ${item.displayName}"
                    },
                    modifier = Modifier.fillMaxSize(),
                    onControlInteraction = { videoInteracting = it },
                )

                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.48f))
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = item.displayName,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White,
                            maxLines = 1,
                        )
                        Text(
                            text = buildString {
                                append(if (item.isVideo) "视频" else "照片")
                                append(" · ")
                                append(formatBytes(item.sizeBytes))
                                item.durationMs?.let {
                                    append(" · ")
                                    append(formatDuration(it))
                                }
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.82f),
                        )
                    }
                }

                if (showHints) {
                    GestureHint(
                        icon = Icons.Filled.KeyboardArrowUp,
                        label = "上滑保留",
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 12.dp),
                    )
                }

                val alpha = min(1f, (abs(currentOffset.x) / (width * 0.24f)).coerceIn(0f, 1f))
                if (currentOffset.x < 0f) {
                    SwipeFeedback(
                        label = "加入待删除",
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.align(Alignment.CenterStart).padding(18.dp),
                        alpha = alpha,
                    )
                } else if (currentOffset.x > 0f) {
                    SwipeFeedback(
                        label = "标记收藏",
                        color = Color(0xFF3E7250),
                        modifier = Modifier.align(Alignment.CenterEnd).padding(18.dp),
                        alpha = alpha,
                    )
                }
            }
        }
    }
}

@Composable
private fun GestureHint(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        shape = CircleShape,
        color = Color.Black.copy(alpha = 0.48f),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = Color.White,
            )
        }
    }
}

@Composable
private fun SwipeFeedback(
    label: String,
    color: Color,
    alpha: Float,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.graphicsLayer { this.alpha = alpha },
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.90f),
    ) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            color = Color.White,
        )
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 1_024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var value = bytes / 1_024.0
    var unitIndex = 0
    while (value >= 1_024 && unitIndex < units.lastIndex) {
        value /= 1_024.0
        unitIndex++
    }
    return "${DecimalFormat("0.#").format(value)} ${units[unitIndex]}"
}

private fun formatDuration(durationMs: Long): String {
    val totalSeconds = durationMs / 1_000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return if (minutes > 0) "${minutes}分${seconds}秒" else "${seconds}秒"
}
