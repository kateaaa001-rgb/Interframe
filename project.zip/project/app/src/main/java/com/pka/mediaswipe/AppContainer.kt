package com.pka.mediaswipe

import android.content.Context
import com.pka.mediaswipe.data.db.MediaSwipeDatabase
import com.pka.mediaswipe.data.media.MediaStoreDataSource
import com.pka.mediaswipe.data.repository.CleaningRepository
import com.pka.mediaswipe.data.repository.FavoritesRepository
import com.pka.mediaswipe.data.repository.SettingsRepository

class AppContainer(context: Context) {
    private val database = MediaSwipeDatabase.getInstance(context)
    val mediaStore = MediaStoreDataSource(context)
    val favoritesRepository = FavoritesRepository(database.favoriteDao(), mediaStore)
    val cleaningRepository = CleaningRepository(database, mediaStore)
    val settingsRepository = SettingsRepository(database.settingsDao())
}
