package com.pka.mediaswipe.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.pka.mediaswipe.AppContainer
import com.pka.mediaswipe.data.db.SessionEntity
import com.pka.mediaswipe.data.media.MediaPermissionSnapshot
import com.pka.mediaswipe.data.repository.CleaningRepository
import com.pka.mediaswipe.data.repository.FavoritesRepository
import com.pka.mediaswipe.data.media.MediaStoreDataSource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class HomeUiState(
    val activeSession: SessionEntity? = null,
    val favoriteCount: Int = 0,
    val mediaCount: Int? = null,
    val scanning: Boolean = false,
    val scanError: String? = null,
    val resetting: Boolean = false,
    val resetMessage: String? = null,
    val resetError: String? = null,
)

class HomeViewModel(
    private val cleaningRepository: CleaningRepository,
    favoritesRepository: FavoritesRepository,
    private val mediaStore: MediaStoreDataSource,
) : ViewModel() {
    private val _state = MutableStateFlow(HomeUiState())
    val state: StateFlow<HomeUiState> = _state.asStateFlow()
    private var lastScanKey: String? = null

    init {
        viewModelScope.launch {
            cleaningRepository.activeSession.collectLatest { session ->
                _state.update { it.copy(activeSession = session) }
            }
        }
        viewModelScope.launch {
            favoritesRepository.count.collectLatest { count ->
                _state.update { it.copy(favoriteCount = count) }
            }
        }
    }

    fun onPermissionsChanged(permission: MediaPermissionSnapshot, forceScan: Boolean = false) {
        val key = "${permission.hasFullAccess}-${permission.hasPartialAccess}-${permission.canReadMedia}"
        if (!forceScan && key == lastScanKey) return
        lastScanKey = key
        if (!permission.canReadMedia) {
            _state.update { it.copy(mediaCount = null, scanning = false, scanError = null) }
            return
        }
        scan()
    }

    fun scan() {
        if (_state.value.scanning) return
        viewModelScope.launch {
            _state.update { it.copy(scanning = true, scanError = null) }
            runCatching { mediaStore.queryAccessibleMedia().size }
                .onSuccess { count ->
                    _state.update { it.copy(mediaCount = count, scanning = false) }
                }
                .onFailure { error ->
                    _state.update {
                        it.copy(
                            mediaCount = null,
                            scanning = false,
                            scanError = error.message ?: "无法读取媒体库",
                        )
                    }
                }
        }
    }

    fun resetProgress() {
        if (_state.value.resetting) return
        viewModelScope.launch {
            _state.update {
                it.copy(
                    resetting = true,
                    resetMessage = null,
                    resetError = null,
                )
            }
            runCatching { cleaningRepository.resetActiveSessionToNewBatch() }
                .onSuccess { reset ->
                    _state.update {
                        it.copy(
                            resetting = false,
                            resetMessage = if (reset) {
                                "进度已重置，新队列最多 50 项"
                            } else {
                                null
                            },
                            resetError = if (reset) null else "没有可重置的清理会话",
                        )
                    }
                }
                .onFailure { error ->
                    _state.update {
                        it.copy(
                            resetting = false,
                            resetError = error.message ?: "重置进度失败",
                        )
                    }
                }
        }
    }

    fun clearResetMessage() {
        _state.update { it.copy(resetMessage = null, resetError = null) }
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                HomeViewModel(
                    cleaningRepository = container.cleaningRepository,
                    favoritesRepository = container.favoritesRepository,
                    mediaStore = container.mediaStore,
                )
            }
        }
    }
}
