package com.pka.mediaswipe.data.repository

import com.pka.mediaswipe.data.db.FavoriteDao
import com.pka.mediaswipe.data.db.FavoriteEntity
import com.pka.mediaswipe.data.media.MediaStoreDataSource
import com.pka.mediaswipe.domain.FavoriteItem
import com.pka.mediaswipe.domain.UriAvailability
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class FavoritesRepository(
    private val dao: FavoriteDao,
    private val mediaStore: MediaStoreDataSource,
) {
    val favorites: Flow<List<FavoriteItem>> = dao.observeAll().map { list ->
        list.map(FavoriteEntity::toDomain)
    }

    val count: Flow<Int> = dao.observeCount()

    suspend fun getAllUris(): Set<String> = dao.getAllUris().toSet()

    suspend fun remove(uri: String) {
        dao.deleteByUri(uri)
    }

    suspend fun removeInvalid(uris: Collection<String>) {
        if (uris.isNotEmpty()) {
            dao.deleteByUris(uris.toList())
        }
    }

    suspend fun unavailableUris(items: List<FavoriteItem>): Set<String> {
        val unavailable = mutableSetOf<String>()
        items.forEach { item ->
            if (mediaStore.availability(item.uri) != UriAvailability.PRESENT) {
                unavailable += item.uri
            }
        }
        return unavailable
    }

    suspend fun save(items: List<FavoriteEntity>) {
        if (items.isNotEmpty()) {
            dao.upsertAll(items)
        }
    }
}

fun FavoriteEntity.toDomain(): FavoriteItem = FavoriteItem(
    uri = uri,
    mediaId = mediaId,
    mimeType = mimeType,
    displayName = displayName,
    sizeBytes = sizeBytes,
    modifiedTime = modifiedTime,
    durationMs = durationMs,
    isVideo = isVideo,
    addedAt = addedAt,
)
