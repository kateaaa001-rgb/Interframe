package com.pka.mediaswipe.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        FavoriteEntity::class,
        SettingsEntity::class,
        SessionEntity::class,
        SessionItemEntity::class,
    ],
    version = 2,
    exportSchema = true,
)
@TypeConverters(Converters::class)
abstract class MediaSwipeDatabase : RoomDatabase() {
    abstract fun favoriteDao(): FavoriteDao
    abstract fun sessionDao(): SessionDao
    abstract fun settingsDao(): SettingsDao

    companion object {
        @Volatile
        private var instance: MediaSwipeDatabase? = null

        fun getInstance(context: Context): MediaSwipeDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    MediaSwipeDatabase::class.java,
                    "mediaswipe.db",
            )
                .addMigrations(MIGRATION_1_2)
                .build()
                .also { instance = it }
            }

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS app_settings_new " +
                        "(id INTEGER NOT NULL, showSwipeHints INTEGER NOT NULL, PRIMARY KEY(id))",
                )
                db.execSQL(
                    "INSERT OR REPLACE INTO app_settings_new (id, showSwipeHints) " +
                        "SELECT id, showSwipeHints FROM app_settings",
                )
                db.execSQL("DROP TABLE app_settings")
                db.execSQL("ALTER TABLE app_settings_new RENAME TO app_settings")
            }
        }
    }
}
