package com.pka.mediaswipe.data.repository

import com.pka.mediaswipe.data.db.SettingsDao
import com.pka.mediaswipe.data.db.SettingsEntity
import com.pka.mediaswipe.domain.AppSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class SettingsRepository(private val dao: SettingsDao) {
    val settings: Flow<AppSettings> = dao.observe().map { entity ->
        entity?.toDomain() ?: AppSettings()
    }

    suspend fun ensureDefaults() {
        if (dao.get() == null) {
            dao.upsert(SettingsEntity())
        }
    }

    suspend fun setHintsEnabled(enabled: Boolean) {
        val current = dao.get() ?: SettingsEntity()
        dao.upsert(current.copy(showSwipeHints = enabled))
    }

    private fun SettingsEntity.toDomain(): AppSettings = AppSettings(
        showSwipeHints = showSwipeHints,
    )
}
