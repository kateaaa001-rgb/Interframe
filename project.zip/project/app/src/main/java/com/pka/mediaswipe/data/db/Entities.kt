package com.pka.mediaswipe.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.pka.mediaswipe.domain.SessionStatus
import com.pka.mediaswipe.domain.SwipeDecision

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val uri: String,
    val mediaId: Long,
    val mimeType: String,
    val displayName: String,
    val sizeBytes: Long,
    val modifiedTime: Long,
    val durationMs: Long?,
    val isVideo: Boolean,
    val addedAt: Long,
)

@Entity(tableName = "app_settings")
data class SettingsEntity(
    @PrimaryKey val id: Int = 1,
    val showSwipeHints: Boolean = true,
)

@Entity(tableName = "cleaning_sessions")
data class SessionEntity(
    @PrimaryKey val id: String,
    val createdAt: Long,
    val updatedAt: Long,
    val status: SessionStatus,
    val totalCount: Int,
    val currentIndex: Int,
    val activeBatchStart: Int,
    val batchLocked: Boolean,
)

@Entity(
    tableName = "session_items",
    primaryKeys = ["sessionId", "position"],
    foreignKeys = [
        ForeignKey(
            entity = SessionEntity::class,
            parentColumns = ["id"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [
        Index(value = ["sessionId", "uri"], unique = true),
        Index(value = ["sessionId", "decision"]),
    ],
)
data class SessionItemEntity(
    val sessionId: String,
    val position: Int,
    val mediaId: Long,
    val uri: String,
    val mimeType: String,
    val displayName: String,
    val sizeBytes: Long,
    val modifiedTime: Long,
    val durationMs: Long?,
    val isVideo: Boolean,
    val decision: SwipeDecision = SwipeDecision.KEEP,
)
