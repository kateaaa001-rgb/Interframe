package com.pka.mediaswipe

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.app.ActivityCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.pka.mediaswipe.data.media.MediaPermissions
import com.pka.mediaswipe.ui.components.MainDestination
import com.pka.mediaswipe.ui.screens.CleaningScreen
import com.pka.mediaswipe.ui.screens.DeveloperScreen
import com.pka.mediaswipe.ui.screens.FavoritesScreen
import com.pka.mediaswipe.ui.screens.HomeScreen
import com.pka.mediaswipe.ui.screens.PrivacyScreen
import com.pka.mediaswipe.ui.screens.SettingsScreen
import com.pka.mediaswipe.ui.theme.MediaSwipeTheme
import com.pka.mediaswipe.ui.viewmodel.CleaningViewModel
import com.pka.mediaswipe.ui.viewmodel.FavoritesViewModel
import com.pka.mediaswipe.ui.viewmodel.HomeViewModel
import com.pka.mediaswipe.ui.viewmodel.SettingsViewModel

private object Routes {
    const val HOME = "home"
    const val FAVORITES = "favorites"
    const val SETTINGS = "settings"
    const val SESSION = "session"
    const val DEVELOPER = "developer"
    const val PRIVACY = "privacy"
}

@Composable
fun MediaSwipeApp(container: AppContainer) {
    val settingsViewModel: SettingsViewModel = viewModel(
        factory = SettingsViewModel.factory(container),
    )
    val settings by settingsViewModel.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val activity = context as Activity
    val navController = rememberNavController()
    var permission by remember { mutableStateOf(MediaPermissions.snapshot(context)) }
    var permissionRequested by rememberSaveable { mutableStateOf(false) }
    var shouldShowRationale by remember { mutableStateOf(false) }
    val lifecycleOwner = LocalLifecycleOwner.current

    fun refreshPermissionState() {
        permission = MediaPermissions.snapshot(context)
        shouldShowRationale = MediaPermissions.requiredPermissions().any { item ->
            ActivityCompat.shouldShowRequestPermissionRationale(activity, item)
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions(),
    ) {
        permissionRequested = true
        refreshPermissionState()
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                refreshPermissionState()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    fun requestPermissions() {
        permissionRequested = true
        permissionLauncher.launch(MediaPermissions.requiredPermissions())
    }

    fun openSystemSettings() {
        activity.startActivity(
            Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", activity.packageName, null),
            ),
        )
    }

    fun navigateTopLevel(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    fun handleMainNavigation(destination: MainDestination) {
        navigateTopLevel(
            when (destination) {
                MainDestination.CLEAN -> Routes.HOME
                MainDestination.FAVORITES -> Routes.FAVORITES
                MainDestination.SETTINGS -> Routes.SETTINGS
            },
        )
    }

    val darkTheme = isSystemInDarkTheme()
    ApplySystemBarIcons(darkTheme)

    MediaSwipeTheme {
        NavHost(navController = navController, startDestination = Routes.HOME) {
            composable(Routes.HOME) {
                val homeViewModel: HomeViewModel = viewModel(
                    factory = HomeViewModel.factory(container),
                )
                HomeScreen(
                    viewModel = homeViewModel,
                    permission = permission,
                    permissionRequested = permissionRequested,
                    shouldShowRationale = shouldShowRationale,
                    onRequestPermission = ::requestPermissions,
                    onOpenSettings = ::openSystemSettings,
                    onStartSession = { navController.navigate(Routes.SESSION) },
                    onNavigate = ::handleMainNavigation,
                )
            }

            composable(Routes.SESSION) {
                val cleaningViewModel: CleaningViewModel = viewModel(
                    factory = CleaningViewModel.factory(container),
                )
                CleaningScreen(
                    viewModel = cleaningViewModel,
                    showSwipeHints = settings.showSwipeHints,
                    onExit = {
                        if (!navController.popBackStack()) {
                            navController.navigate(Routes.HOME)
                        }
                    },
                    onViewFavorites = { navigateTopLevel(Routes.FAVORITES) },
                )
            }

            composable(Routes.FAVORITES) {
                val favoritesViewModel: FavoritesViewModel = viewModel(
                    factory = FavoritesViewModel.factory(container),
                )
                FavoritesScreen(
                    viewModel = favoritesViewModel,
                    onNavigate = ::handleMainNavigation,
                )
            }

            composable(Routes.SETTINGS) {
                SettingsScreen(
                    viewModel = settingsViewModel,
                    permission = permission,
                    permissionRequested = permissionRequested,
                    shouldShowRationale = shouldShowRationale,
                    onRequestPermission = ::requestPermissions,
                    onOpenSettings = ::openSystemSettings,
                    onOpenPrivacy = { navController.navigate(Routes.PRIVACY) },
                    onOpenDeveloper = { navController.navigate(Routes.DEVELOPER) },
                    onNavigate = ::handleMainNavigation,
                )
            }

            composable(Routes.DEVELOPER) {
                DeveloperScreen(
                    onBack = { navController.popBackStack() },
                    onOpenPrivacy = { navController.navigate(Routes.PRIVACY) },
                )
            }

            composable(Routes.PRIVACY) {
                PrivacyScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}

@Composable
private fun ApplySystemBarIcons(darkTheme: Boolean) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !darkTheme
                isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }
}
