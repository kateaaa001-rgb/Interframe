package com.pka.mediaswipe.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pka.mediaswipe.BuildConfig
import com.pka.mediaswipe.data.media.MediaPermissionSnapshot
import com.pka.mediaswipe.ui.components.AppBottomBar
import com.pka.mediaswipe.ui.components.MainDestination
import com.pka.mediaswipe.ui.components.PermissionStatusRow
import com.pka.mediaswipe.ui.components.SectionCard
import com.pka.mediaswipe.ui.viewmodel.HomeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    permission: MediaPermissionSnapshot,
    permissionRequested: Boolean,
    shouldShowRationale: Boolean,
    onRequestPermission: () -> Unit,
    onOpenSettings: () -> Unit,
    onStartSession: () -> Unit,
    onNavigate: (MainDestination) -> Unit,
) {
    val state by viewModel.state.collectAsState()
    var showPermissionIntro by rememberSaveable { mutableStateOf(false) }
    var showResetConfirm by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(permission) {
        viewModel.onPermissionsChanged(permission)
    }

    if (showPermissionIntro) {
        AlertDialog(
            onDismissRequest = { showPermissionIntro = false },
            title = { Text("先说明媒体访问用途") },
            text = {
                Text(
                    "帧间需要读取你授权范围内的照片和视频，才能在本机生成随机清理队列。" +
                        "媒体内容不会上传；收藏、设置与会话进度只保存在设备本地。" +
                        "删除操作还会再次经过 Android 系统授权。",
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showPermissionIntro = false
                        onRequestPermission()
                    },
                ) { Text("继续授权") }
            },
            dismissButton = {
                TextButton(onClick = { showPermissionIntro = false }) { Text("暂不授权") }
            },
        )
    }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text("重置清理进度？") },
            text = {
                Text(
                    "当前会话未提交的进度和待处理标记会被放弃，并重新生成最多 50 项的随机队列。" +
                        "已完成的删除和已保存的收藏不会回滚。",
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showResetConfirm = false
                        viewModel.resetProgress()
                    },
                ) { Text("确认重置") }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirm = false }) { Text("取消") }
            },
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(BuildConfig.APP_NAME, style = MaterialTheme.typography.titleLarge)
                        Text(
                            "这一帧，交给曾经的你",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
            )
        },
        bottomBar = {
            AppBottomBar(selected = MainDestination.CLEAN, onSelect = onNavigate)
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.padding(innerPadding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                start = 18.dp,
                end = 18.dp,
                top = 12.dp,
                bottom = 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                Text(
                    "用刷视频的方式回忆从前，清理空间，收藏记忆",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                )
            }

            item {
                SectionCard {
                    PermissionStatusRow(permission)
                    if (!permission.hasFullAccess) {
                        Text(
                            if (permission.hasPartialAccess) {
                                "部分访问模式下，可访问数量会少于相册总量。你可以重新选择更多媒体，或前往系统设置授予完整访问。"
                            } else {
                                "本应用不会申请广泛文件管理权限，也不会访问其他应用私有目录。"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        if (!permission.canReadMedia) {
                            OutlinedButton(
                                onClick = {
                                    when {
                                        !permissionRequested -> showPermissionIntro = true
                                        shouldShowRationale -> onRequestPermission()
                                        else -> onOpenSettings()
                                    }
                                },
                                modifier = Modifier.weight(1f),
                            ) {
                                Text(
                                    when {
                                        !permissionRequested -> "说明并授权"
                                        shouldShowRationale -> "再次请求权限"
                                        else -> "前往系统设置"
                                    },
                                )
                            }
                        } else if (permission.hasPartialAccess) {
                            OutlinedButton(
                                onClick = onRequestPermission,
                                modifier = Modifier.weight(1f),
                            ) { Text("扩大访问范围") }
                        }
                        if (permission.hasPartialAccess || (permissionRequested && !permission.canReadMedia)) {
                            TextButton(onClick = onOpenSettings) { Text("系统设置") }
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    MetricCard(
                        label = "可访问媒体",
                        value = when {
                            !permission.canReadMedia -> "—"
                            state.scanning -> "扫描中"
                            state.mediaCount != null -> "${state.mediaCount} 项"
                            else -> "—"
                        },
                        modifier = Modifier.weight(1f),
                    )
                    MetricCard(
                        label = "本地收藏",
                        value = "${state.favoriteCount} 项",
                        modifier = Modifier.weight(1f),
                    )
                }
            }

            state.activeSession?.let { session ->
                item {
                    SectionCard {
                        Text("有一轮清理尚未结束", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "已审核 ${session.currentIndex} / ${session.totalCount} 项，进度已保存在本机。",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        LinearProgressIndicator(
                            progress = {
                                if (session.totalCount == 0) 0f else {
                                    session.currentIndex.toFloat() / session.totalCount
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }

            item {
                Button(
                    onClick = {
                        if (permission.canReadMedia) {
                            onStartSession()
                        } else if (!permissionRequested) {
                            showPermissionIntro = true
                        } else if (shouldShowRationale) {
                            onRequestPermission()
                        } else {
                            onOpenSettings()
                        }
                    },
                    enabled = !state.scanning,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                ) {
                    Text(
                        when {
                            !permission.canReadMedia -> "授权后开始"
                            state.activeSession != null -> "继续上次清理"
                            else -> "开始随机清理"
                        },
                        style = MaterialTheme.typography.titleSmall,
                    )
                }
                if (permission.canReadMedia) {
                    TextButton(
                        onClick = { viewModel.scan() },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        androidx.compose.material3.Icon(
                            Icons.Filled.Refresh,
                            contentDescription = null,
                        )
                        Text("重新扫描媒体库", modifier = Modifier.padding(start = 6.dp))
                    }
                }
                OutlinedButton(
                    onClick = { showResetConfirm = true },
                    enabled = state.activeSession != null && !state.resetting,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(if (state.resetting) "正在重置" else "重置进度")
                }
                state.resetMessage?.let {
                    Text(
                        it,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                state.resetError?.let {
                    Text(
                        it,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                state.scanError?.let {
                    Text(
                        it,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }

            item {
                SectionCard {
                    Text("滑动含义", style = MaterialTheme.typography.titleSmall)
                    GestureRow(
                        icon = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                        title = "左滑",
                        detail = "加入本批待删除，不会立即删除文件",
                        tint = MaterialTheme.colorScheme.error,
                    )
                    GestureRow(
                        icon = Icons.Filled.KeyboardArrowUp,
                        title = "上滑",
                        detail = "保留并查看下一项，不写入删除或收藏队列",
                        tint = MaterialTheme.colorScheme.primary,
                    )
                    GestureRow(
                        icon = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        title = "右滑",
                        detail = "加入本批待收藏，批次确认后才写入本地收藏",
                        tint = Color(0xFF3E7250),
                    )
                    Text(
                        "从屏幕边缘横向滑动会优先交给系统返回手势；应用内按钮可替代所有滑动手势。",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun MetricCard(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            Text(
                value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun GestureRow(
    icon: ImageVector,
    title: String,
    detail: String,
    tint: Color,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        androidx.compose.material3.Icon(icon, contentDescription = null, tint = tint)
        Column {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Text(
                detail,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
