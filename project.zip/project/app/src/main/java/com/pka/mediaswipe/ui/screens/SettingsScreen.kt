package com.pka.mediaswipe.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pka.mediaswipe.BuildConfig
import com.pka.mediaswipe.data.media.MediaPermissionSnapshot
import com.pka.mediaswipe.ui.components.AppBottomBar
import com.pka.mediaswipe.ui.components.ExternalLinkRow
import com.pka.mediaswipe.ui.components.MainDestination
import com.pka.mediaswipe.ui.components.PermissionStatusRow
import com.pka.mediaswipe.ui.components.SectionCard
import com.pka.mediaswipe.ui.viewmodel.SettingsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    permission: MediaPermissionSnapshot,
    permissionRequested: Boolean,
    shouldShowRationale: Boolean,
    onRequestPermission: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenPrivacy: () -> Unit,
    onOpenDeveloper: () -> Unit,
    onNavigate: (MainDestination) -> Unit,
) {
    val settings by viewModel.settings.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("设置", style = MaterialTheme.typography.titleLarge) })
        },
        bottomBar = {
            AppBottomBar(selected = MainDestination.SETTINGS, onSelect = onNavigate)
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                SectionCard {
                    Text("郑重声明", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "我们始终坚持隐私是一项基本人权，本软件不上传或索要任何非必要数据，" +
                            "并且提醒用户及时关闭此软件的联网权限也可以用",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }

            item {
                SectionCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("显示滑动提示", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "在媒体卡片顶部显示滑动方向提示。",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Switch(
                            checked = settings.showSwipeHints,
                            onCheckedChange = viewModel::setHintsEnabled,
                        )
                    }
                }
            }

            item {
                SectionCard {
                    Text("媒体权限", style = MaterialTheme.typography.titleMedium)
                    PermissionStatusRow(permission)
                    if (permission.hasPartialAccess) {
                        Text(
                            "当前只授权了部分媒体，应用会按实际可读取范围处理。",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        if (!permission.hasFullAccess) {
                            OutlinedButton(
                                onClick = {
                                    if (!permissionRequested || shouldShowRationale) {
                                        onRequestPermission()
                                    } else {
                                        onOpenSettings()
                                    }
                                },
                                modifier = Modifier.weight(1f),
                            ) {
                                Text(if (permission.hasPartialAccess) "重新选择媒体" else "恢复权限")
                            }
                        }
                        Button(
                            onClick = onOpenSettings,
                            modifier = Modifier.weight(1f),
                        ) { Text("系统设置") }
                    }
                }
            }

            item {
                SectionCard {
                    Text("关于与声明", style = MaterialTheme.typography.titleMedium)
                    OutlinedButton(
                        onClick = onOpenPrivacy,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("隐私声明与免责声明") }
                    OutlinedButton(
                        onClick = onOpenDeveloper,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("开发者信息") }
                    HorizontalDivider()
                    ExternalLinkRow("开发者个人博客", BuildConfig.BLOG_URL)
                    ExternalLinkRow("开发组织官网", BuildConfig.ORGANIZATION_URL)
                    ExternalLinkRow("用户协议", BuildConfig.TERMS_URL)
                    ExternalLinkRow("隐私协议", BuildConfig.PRIVACY_URL)
                    ExternalLinkRow("app官网", BuildConfig.APP_SITE_URL)
                    ExternalLinkRow("开源地址", BuildConfig.REPOSITORY_URL)
                }
            }

            item {
                SectionCard {
                    Text(
                        "${BuildConfig.APP_NAME} ${BuildConfig.VERSION_NAME}",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Text(
                        "开发者：${BuildConfig.DEVELOPER_NAME}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        BuildConfig.ORGANIZATION_NAME,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    TextButton(onClick = onOpenPrivacy) { Text("查看完整声明") }
                }
            }
        }
    }
}
