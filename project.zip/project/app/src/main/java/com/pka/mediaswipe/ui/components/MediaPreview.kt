package com.pka.mediaswipe.ui.components

import android.annotation.SuppressLint
import android.graphics.Color as AndroidColor
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

@Composable
fun MediaPreview(
    uri: String,
    isVideo: Boolean,
    contentDescription: String,
    modifier: Modifier = Modifier,
    allowVideoControls: Boolean = true,
    onControlInteraction: (Boolean) -> Unit = {},
) {
    if (isVideo) {
        VideoPreview(
            uri = uri,
            contentDescription = contentDescription,
            modifier = modifier,
            allowVideoControls = allowVideoControls,
            onControlInteraction = onControlInteraction,
        )
    } else {
        PhotoPreview(
            uri = uri,
            contentDescription = contentDescription,
            modifier = modifier,
        )
    }
}

@Composable
private fun PhotoPreview(
    uri: String,
    contentDescription: String,
    modifier: Modifier,
) {
    val context = LocalContext.current
    var failed by remember(uri) { mutableStateOf(false) }
    Box(modifier = modifier.background(Color(0xFF0B0D0B)), contentAlignment = Alignment.Center) {
        AsyncImage(
            model = ImageRequest.Builder(context)
                .data(uri)
                .crossfade(true)
                .build(),
            contentDescription = contentDescription,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize(),
            onError = { failed = true },
        )
        if (failed) {
            UnavailableMedia(message = "无法加载这张照片")
        }
    }
}

@SuppressLint("UnsafeOptInUsageError")
@Composable
private fun VideoPreview(
    uri: String,
    contentDescription: String,
    modifier: Modifier,
    allowVideoControls: Boolean,
    onControlInteraction: (Boolean) -> Unit,
) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    var muted by remember(uri) { mutableStateOf(false) }
    var playing by remember(uri) { mutableStateOf(true) }
    var positionMs by remember(uri) { mutableLongStateOf(0L) }
    var durationMs by remember(uri) { mutableLongStateOf(0L) }
    var playbackError by remember(uri) { mutableStateOf<String?>(null) }
    val player = remember(uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            volume = 1f
            prepare()
            playWhenReady = true
            setHandleAudioBecomingNoisy(true)
        }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playing = isPlaying
            }

            override fun onPlayerError(error: PlaybackException) {
                playbackError = "视频无法播放，请检查媒体是否仍可访问"
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    DisposableEffect(lifecycle, player) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) player.pause()
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(muted, player) {
        player.volume = if (muted) 0f else 1f
    }

    LaunchedEffect(player) {
        while (isActive) {
            positionMs = player.currentPosition.coerceAtLeast(0L)
            durationMs = player.duration.coerceAtLeast(0L)
            delay(500)
        }
    }

    fun playFromCurrentOrStart() {
        if (player.playbackState == Player.STATE_ENDED) player.seekTo(0)
        player.play()
    }

    Box(
        modifier = modifier.background(Color.Black),
        contentAlignment = Alignment.Center,
    ) {
        AndroidView(
            factory = { viewContext ->
                PlayerView(viewContext).apply {
                    this.player = player
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    setShutterBackgroundColor(AndroidColor.TRANSPARENT)
                    this.contentDescription = contentDescription
                    isClickable = false
                    isFocusable = false
                }
            },
            update = { it.player = player },
            modifier = Modifier.fillMaxSize(),
        )

        if (playbackError != null) {
            UnavailableMedia(message = playbackError ?: "视频无法播放")
        } else if (!playing) {
            FilledTonalButton(
                onClick = { playFromCurrentOrStart() },
                modifier = Modifier.align(Alignment.Center),
            ) {
                Text("播放")
            }
        }

        if (allowVideoControls && playbackError == null) {
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(8.dp),
                color = Color.Black.copy(alpha = 0.62f),
            ) {
                Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = "${formatTime(positionMs)} / ${formatTime(durationMs)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                        )
                        Row {
                            TextButton(onClick = {
                                if (player.isPlaying) player.pause() else playFromCurrentOrStart()
                            }) {
                                Text(
                                    if (playing) "暂停" else "播放",
                                    color = Color.White,
                                )
                            }
                            TextButton(onClick = { muted = !muted }) {
                                Text(
                                    if (muted) "打开声音" else "静音",
                                    color = Color.White,
                                )
                            }
                        }
                    }
                    Slider(
                        value = positionMs.coerceAtMost(durationMs.coerceAtLeast(1L)).toFloat(),
                        onValueChange = { value ->
                            onControlInteraction(true)
                            positionMs = value.toLong()
                            player.seekTo(value.toLong())
                        },
                        onValueChangeFinished = { onControlInteraction(false) },
                        valueRange = 0f..durationMs.coerceAtLeast(1L).toFloat(),
                    )
                }
            }
        }
    }
}

@Composable
private fun UnavailableMedia(message: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.96f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Icon(
                Icons.Filled.Warning,
                contentDescription = null,
                modifier = Modifier.size(42.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Text(
                text = "文件可能已被移动或删除",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

private fun formatTime(valueMs: Long): String {
    val totalSeconds = (valueMs.coerceAtLeast(0L) / 1_000L)
    val hours = totalSeconds / 3_600L
    val minutes = (totalSeconds % 3_600L) / 60L
    val seconds = totalSeconds % 60L
    return if (hours > 0) {
        "%d:%02d:%02d".format(hours, minutes, seconds)
    } else {
        "%d:%02d".format(minutes, seconds)
    }
}
