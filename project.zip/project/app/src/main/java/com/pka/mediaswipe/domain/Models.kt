package com.pka.mediaswipe.domain

import kotlin.math.min
import kotlin.random.Random

const val BATCH_SIZE = 50

enum class SwipeDecision {
    KEEP,
    DELETE,
    FAVORITE,
    DELETED,
    FAVORITE_SAVED,
    FAILED_SKIPPED,
}

enum class SessionStatus {
    ACTIVE,
    COMPLETED,
}

data class MediaInfo(
    val id: Long,
    val uri: String,
    val mimeType: String,
    val displayName: String,
    val sizeBytes: Long,
    val modifiedTime: Long,
    val durationMs: Long?,
    val isVideo: Boolean,
)

data class FavoriteItem(
    val uri: String,
    val mediaId: Long,
    val mimeType: String,
    val displayName: String,
    val sizeBytes: Long,
    val modifiedTime: Long,
    val durationMs: Long?,
    val isVideo: Boolean,
    val addedAt: Long,
)

data class AppSettings(
    val showSwipeHints: Boolean = true,
)

data class SessionStats(
    val kept: Int = 0,
    val deleted: Int = 0,
    val favorited: Int = 0,
)

data class BatchSelection(
    val deleteSelected: Boolean = false,
    val favoriteSelected: Boolean = false,
)

enum class UriAvailability {
    PRESENT,
    MISSING,
    ACCESS_LOST,
}

enum class DeleteFailureReason {
    USER_CANCELLED,
    MEDIA_STILL_PRESENT,
    ACCESS_LOST,
    REQUEST_FAILED,
}

data class DeleteFailure(
    val uri: String,
    val reason: DeleteFailureReason,
)

data class DeleteReconciliation(
    val deletedUris: Set<String> = emptySet(),
    val failures: List<DeleteFailure> = emptyList(),
)

object DeleteResultReconciler {
    fun reconcile(
        authorized: Boolean,
        requestedUris: List<String>,
        availability: Map<String, UriAvailability>,
    ): DeleteReconciliation {
        if (!authorized) {
            return DeleteReconciliation(
                failures = requestedUris.map { DeleteFailure(it, DeleteFailureReason.USER_CANCELLED) },
            )
        }

        val deleted = mutableSetOf<String>()
        val failures = mutableListOf<DeleteFailure>()
        requestedUris.forEach { uri ->
            when (availability[uri] ?: UriAvailability.ACCESS_LOST) {
                UriAvailability.MISSING -> deleted += uri
                UriAvailability.PRESENT ->
                    failures += DeleteFailure(uri, DeleteFailureReason.MEDIA_STILL_PRESENT)
                UriAvailability.ACCESS_LOST ->
                    failures += DeleteFailure(uri, DeleteFailureReason.ACCESS_LOST)
            }
        }
        return DeleteReconciliation(deletedUris = deleted, failures = failures)
    }
}

object BatchSelectionPolicy {
    fun canConfirm(
        selection: BatchSelection,
        hasPendingDeletes: Boolean,
        hasPendingFavorites: Boolean,
    ): Boolean = (selection.deleteSelected && hasPendingDeletes) ||
        (selection.favoriteSelected && hasPendingFavorites)

    fun executeDelete(selection: BatchSelection, hasPendingDeletes: Boolean): Boolean =
        selection.deleteSelected && hasPendingDeletes

    fun executeFavorite(selection: BatchSelection, hasPendingFavorites: Boolean): Boolean =
        selection.favoriteSelected && hasPendingFavorites
}

object SessionRules {
    fun batchSize(batchStart: Int, total: Int): Int {
        if (total <= 0 || batchStart >= total) return 0
        return min(BATCH_SIZE, total - batchStart)
    }

    fun batchEnd(batchStart: Int, total: Int): Int =
        min(total, batchStart + batchSize(batchStart, total))

    fun resetBatchSize(available: Int): Int =
        available.coerceIn(0, BATCH_SIZE)

    fun displayPosition(reviewed: Int, batchStart: Int): Int =
        (reviewed - batchStart).coerceAtLeast(0) + 1

    fun isBatchBoundary(reviewed: Int, total: Int, batchStart: Int = 0): Boolean =
        reviewed > batchStart && (reviewed % BATCH_SIZE == 0 || reviewed >= total)

    fun canUndo(reviewed: Int, batchStart: Int, batchLocked: Boolean): Boolean =
        !batchLocked && reviewed > batchStart

    fun requiresConfirmation(decisions: Collection<SwipeDecision>): Boolean =
        decisions.any { it == SwipeDecision.DELETE || it == SwipeDecision.FAVORITE }
}

object MediaRandomizer {
    fun shuffle(items: List<MediaInfo>, random: Random = Random.Default): List<MediaInfo> {
        val result = items.distinctBy { it.uri }.toMutableList()
        for (index in result.lastIndex downTo 1) {
            val target = random.nextInt(index + 1)
            val current = result[index]
            result[index] = result[target]
            result[target] = current
        }
        return result
    }
}

data class SessionDecisionLedger(
    val total: Int,
    val batchStart: Int = 0,
    val currentIndex: Int = 0,
    private val decisions: Map<Int, SwipeDecision> = emptyMap(),
) {
    val batchSize: Int get() = SessionRules.batchSize(batchStart, total)
    val atBatchBoundary: Boolean
        get() = SessionRules.isBatchBoundary(currentIndex, total, batchStart)
    val canUndo: Boolean get() = SessionRules.canUndo(currentIndex, batchStart, false)
    val pendingDeletePositions: List<Int>
        get() = currentBatchDecisions(SwipeDecision.DELETE)
    val pendingFavoritePositions: List<Int>
        get() = currentBatchDecisions(SwipeDecision.FAVORITE)
    val requiresConfirmation: Boolean
        get() = SessionRules.requiresConfirmation(currentBatchDecisionValues())

    fun record(decision: SwipeDecision): SessionDecisionLedger {
        require(currentIndex < total) { "会话已审核完成" }
        require(!atBatchBoundary) { "批次边界必须先处理确认流程" }
        return copy(
            currentIndex = currentIndex + 1,
            decisions = decisions + (currentIndex to decision),
        )
    }

    fun undoLast(): SessionDecisionLedger? {
        if (!canUndo) return null
        val position = currentIndex - 1
        return copy(
            currentIndex = position,
            decisions = decisions - position,
        )
    }

    fun markOutcome(
        deletedPositions: Set<Int> = emptySet(),
        favoriteSavedPositions: Set<Int> = emptySet(),
        skippedDeletePositions: Set<Int> = emptySet(),
    ): SessionDecisionLedger {
        var updated = decisions
        deletedPositions.forEach { updated = updated + (it to SwipeDecision.DELETED) }
        favoriteSavedPositions.forEach {
            updated = updated + (it to SwipeDecision.FAVORITE_SAVED)
        }
        skippedDeletePositions.forEach {
            updated = updated + (it to SwipeDecision.FAILED_SKIPPED)
        }
        return copy(decisions = updated)
    }

    fun finishResolvedBatch(): SessionDecisionLedger? {
        if (!atBatchBoundary) return null
        if (pendingDeletePositions.isNotEmpty() || pendingFavoritePositions.isNotEmpty()) return null
        return copy(batchStart = currentIndex)
    }

    private fun currentBatchDecisions(decision: SwipeDecision): List<Int> =
        ((batchStart) until currentIndex).filter { decisions[it] == decision }

    private fun currentBatchDecisionValues(): List<SwipeDecision> =
        ((batchStart) until currentIndex).mapNotNull(decisions::get)
}
