package com.pka.mediaswipe.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.pka.mediaswipe.AppContainer
import com.pka.mediaswipe.data.repository.FavoritesRepository
import com.pka.mediaswipe.domain.FavoriteItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class FavoritesUiState(
    val items: List<FavoriteItem> = emptyList(),
    val unavailableUris: Set<String> = emptySet(),
    val checking: Boolean = false,
    val loaded: Boolean = false,
)

class FavoritesViewModel(
    private val repository: FavoritesRepository,
) : ViewModel() {
    private val _state = MutableStateFlow(FavoritesUiState())
    val state: StateFlow<FavoritesUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            repository.favorites.collectLatest { items ->
                _state.update {
                    it.copy(
                        items = items,
                        loaded = true,
                        unavailableUris = it.unavailableUris.intersect(items.map(FavoriteItem::uri).toSet()),
                    )
                }
            }
        }
    }

    fun refreshValidity() {
        val items = _state.value.items
        if (_state.value.checking) return
        viewModelScope.launch {
            _state.update { it.copy(checking = true) }
            val unavailable = repository.unavailableUris(items)
            _state.update { it.copy(unavailableUris = unavailable, checking = false) }
        }
    }

    fun remove(uri: String) {
        viewModelScope.launch { repository.remove(uri) }
    }

    fun removeAllUnavailable() {
        val invalid = _state.value.unavailableUris
        viewModelScope.launch {
            repository.removeInvalid(invalid)
            _state.update { it.copy(unavailableUris = emptySet()) }
        }
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                FavoritesViewModel(container.favoritesRepository)
            }
        }
    }
}
