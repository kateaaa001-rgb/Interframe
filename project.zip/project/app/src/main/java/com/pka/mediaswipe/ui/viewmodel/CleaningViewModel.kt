package com.pka.mediaswipe.ui.viewmodel

import android.app.PendingIntent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.pka.mediaswipe.AppContainer
import com.pka.mediaswipe.data.db.SessionEntity
import com.pka.mediaswipe.data.db.SessionItemEntity
import com.pka.mediaswipe.data.media.MediaStoreDataSource
import com.pka.mediaswipe.data.repository.CleaningRepository
import com.pka.mediaswipe.data.repository.SessionSnapshot
import com.pka.mediaswipe.domain.BatchSelection
import com.pka.mediaswipe.domain.BatchSelectionPolicy
import com.pka.mediaswipe.domain.DeleteFailure
import com.pka.mediaswipe.domain.DeleteFailureReason
import com.pka.mediaswipe.domain.DeleteResultReconciler
import com.pka.mediaswipe.domain.SessionRules
import com.pka.mediaswipe.domain.SessionStats
import com.pka.mediaswipe.domain.SessionStatus
import com.pka.mediaswipe.domain.SwipeDecision
import com.pka.mediaswipe.domain.UriAvailability
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class CleaningPhase {
    LOADING,
    READY,
    EMPTY,
    COMPLETED,
    ERROR,
}

data class BatchOperationResult(
    val favoritesSaved: Int = 0,
    val favoriteFailures: Int = 0,
    val deletedCount: Int = 0,
    val deleteFailures: List<DeleteFailure> = emptyList(),
    val deleteAttempted: Boolean = false,
    val requestFailed: Boolean = false,
) {
    val hasDeleteFailures: Boolean get() = deleteFailures.isNotEmpty()
    val hasFavoriteFailures: Boolean get() = favoriteFailures > 0
    val hasFailures: Boolean get() = hasDeleteFailures || hasFavoriteFailures
}

data class CleaningUiState(
    val phase: CleaningPhase = CleaningPhase.LOADING,
    val session: SessionEntity? = null,
    val items: List<SessionItemEntity> = emptyList(),
    val currentItem: SessionItemEntity? = null,
    val total: Int = 0,
    val reviewed: Int = 0,
    val activeBatchStart: Int = 0,
    val currentBatchSize: Int = 0,
    val positionInBatch: Int = 0,
    val pendingDeletes: List<SessionItemEntity> = emptyList(),
    val pendingFavorites: List<SessionItemEntity> = emptyList(),
    val atBatchBoundary: Boolean = false,
    val canSwipe: Boolean = false,
    val canUndo: Boolean = false,
    val batchDialogVisible: Boolean = false,
    val discardDialogVisible: Boolean = false,
    val operationResult: BatchOperationResult? = null,
    val busy: Boolean = false,
    val awaitingSystemDelete: Boolean = false,
    val stats: SessionStats = SessionStats(),
    val error: String? = null,
)

sealed interface CleaningEvent {
    data class LaunchDeleteAuthorization(val pendingIntent: PendingIntent) : CleaningEvent
}

class CleaningViewModel(
    private val repository: CleaningRepository,
    private val mediaStore: MediaStoreDataSource,
) : ViewModel() {
    private val _state = MutableStateFlow(CleaningUiState())
    val state: StateFlow<CleaningUiState> = _state.asStateFlow()

    private val eventChannel = Channel<CleaningEvent>(Channel.BUFFERED)
    val events = eventChannel.receiveAsFlow()

    private var loaded = false
    private var inFlightDeleteUris: List<String> = emptyList()
    private var inFlightFavoriteSaved = 0
    private var inFlightFavoriteFailures = 0

    fun loadOrCreate() {
        if (loaded) return
        loaded = true
        viewModelScope.launch {
            _state.update { it.copy(phase = CleaningPhase.LOADING, error = null) }
            runCatching { repository.loadOrCreateSession() }
                .onSuccess { snapshot ->
                    if (snapshot == null) {
                        _state.update { it.copy(phase = CleaningPhase.EMPTY) }
                    } else {
                        renderSnapshot(snapshot, showBatchDialog = true)
                    }
                }
                .onFailure { error ->
                    _state.update {
                        it.copy(
                            phase = CleaningPhase.ERROR,
                            error = error.message ?: "无法创建清理会话",
                        )
                    }
                }
        }
    }

    fun swipe(decision: SwipeDecision) {
        val current = _state.value
        if (!current.canSwipe || current.busy) return
        val session = current.session ?: return
        val item = current.currentItem ?: return
        viewModelScope.launch {
            _state.update { it.copy(busy = true) }
            runCatching {
                repository.applyDecision(session.id, item.position, decision)
            }.onSuccess {
                refresh(showBatchDialog = true)
            }.onFailure { error ->
                _state.update {
                    it.copy(busy = false, error = error.message ?: "保存滑动结果失败")
                }
            }
        }
    }

    fun undo() {
        val current = _state.value
        if (!current.canUndo || current.busy) return
        val session = current.session ?: return
        val position = current.reviewed - 1
        viewModelScope.launch {
            _state.update { it.copy(busy = true) }
            runCatching {
                repository.undoDecision(session.id, position)
            }.onSuccess {
                refresh(showBatchDialog = false)
            }.onFailure { error ->
                _state.update {
                    it.copy(busy = false, error = error.message ?: "撤销失败")
                }
            }
        }
    }

    fun dismissBatchDialog() {
        _state.update { it.copy(batchDialogVisible = false) }
    }

    fun openBatchDialog() {
        val current = _state.value
        if (current.pendingDeletes.isNotEmpty() || current.pendingFavorites.isNotEmpty()) {
            _state.update { it.copy(batchDialogVisible = true) }
        }
    }

    fun requestDiscardMarks() {
        _state.update { it.copy(discardDialogVisible = true) }
    }

    fun cancelDiscardMarks() {
        _state.update { it.copy(discardDialogVisible = false) }
    }

    fun confirmDiscardMarks() {
        val session = _state.value.session ?: return
        viewModelScope.launch {
            _state.update {
                it.copy(
                    busy = true,
                    discardDialogVisible = false,
                    batchDialogVisible = false,
                )
            }
            runCatching {
                repository.clearPendingBatchDecisions(session.id)
                repository.finalizeBatch(session.id)
            }.onSuccess { snapshot ->
                if (snapshot == null) {
                    _state.update { it.copy(busy = false, error = "会话不存在") }
                } else {
                    renderSnapshot(snapshot, showBatchDialog = false)
                }
            }.onFailure { error ->
                _state.update {
                    it.copy(busy = false, error = error.message ?: "放弃标记失败")
                }
            }
        }
    }

    fun confirmBatch(selection: BatchSelection) {
        val current = _state.value
        if (current.busy) return
        if (!BatchSelectionPolicy.canConfirm(
                selection = selection,
                hasPendingDeletes = current.pendingDeletes.isNotEmpty(),
                hasPendingFavorites = current.pendingFavorites.isNotEmpty(),
            )
        ) {
            return
        }
        val session = current.session ?: return
        val shouldDelete = BatchSelectionPolicy.executeDelete(
            selection,
            current.pendingDeletes.isNotEmpty(),
        )
        val shouldFavorite = BatchSelectionPolicy.executeFavorite(
            selection,
            current.pendingFavorites.isNotEmpty(),
        )
        val favorites = current.pendingFavorites
        val deletes = current.pendingDeletes

        viewModelScope.launch {
            _state.update {
                it.copy(
                    busy = true,
                    batchDialogVisible = false,
                    operationResult = null,
                    error = null,
                )
            }
            var favoritesSaved = 0
            var favoriteFailures = 0
            if (shouldFavorite) {
                runCatching { repository.saveFavorites(session.id, favorites) }
                    .onSuccess { favoritesSaved = favorites.size }
                    .onFailure { favoriteFailures = favorites.size }
            }

            if (!shouldDelete) {
                val result = BatchOperationResult(
                    favoritesSaved = favoritesSaved,
                    favoriteFailures = favoriteFailures,
                    deleteAttempted = false,
                )
                refresh(showBatchDialog = false, result = result)
                return@launch
            }

            val request = runCatching {
                mediaStore.createDeleteRequest(deletes.map(SessionItemEntity::uri))
            }
            request.onSuccess { pendingIntent ->
                inFlightDeleteUris = deletes.map(SessionItemEntity::uri)
                inFlightFavoriteSaved = favoritesSaved
                inFlightFavoriteFailures = favoriteFailures
                _state.update {
                    it.copy(busy = true, awaitingSystemDelete = true)
                }
                eventChannel.send(CleaningEvent.LaunchDeleteAuthorization(pendingIntent))
            }.onFailure { error ->
                val result = BatchOperationResult(
                    favoritesSaved = favoritesSaved,
                    favoriteFailures = favoriteFailures,
                    deleteFailures = deletes.map {
                        DeleteFailure(it.uri, DeleteFailureReason.REQUEST_FAILED)
                    },
                    deleteAttempted = true,
                    requestFailed = true,
                )
                if (favoritesSaved > 0) {
                    repository.setBatchLocked(session.id, true)
                }
                refresh(showBatchDialog = false, result = result)
                _state.update {
                    it.copy(error = error.message ?: "无法创建系统删除请求")
                }
            }
        }
    }

    fun onDeleteAuthorizationResult(authorized: Boolean) {
        val current = _state.value
        val session = current.session ?: return
        val requested = inFlightDeleteUris
        if (requested.isEmpty()) {
            _state.update { it.copy(busy = false, awaitingSystemDelete = false) }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(busy = true, awaitingSystemDelete = false) }
            val availability = requested.associateWith { uri ->
                mediaStore.availability(uri)
            }
            val reconciliation = DeleteResultReconciler.reconcile(
                authorized = authorized,
                requestedUris = requested,
                availability = availability,
            )
            if (authorized) {
                repository.setBatchLocked(session.id, true)
            }
            if (reconciliation.deletedUris.isNotEmpty()) {
                val deletedPositions = current.items
                    .filter { it.uri in reconciliation.deletedUris }
                    .map(SessionItemEntity::position)
                repository.setDecisionPositions(
                    session.id,
                    deletedPositions,
                    SwipeDecision.DELETED,
                )
            }
            val result = BatchOperationResult(
                favoritesSaved = inFlightFavoriteSaved,
                favoriteFailures = inFlightFavoriteFailures,
                deletedCount = reconciliation.deletedUris.size,
                deleteFailures = reconciliation.failures,
                deleteAttempted = true,
            )
            inFlightDeleteUris = emptyList()
            inFlightFavoriteSaved = 0
            inFlightFavoriteFailures = 0
            refresh(showBatchDialog = false, result = result)
        }
    }

    fun retryFailedDeletes() {
        val current = _state.value
        if (current.busy || current.pendingDeletes.isEmpty()) return
        val session = current.session ?: return
        viewModelScope.launch {
            _state.update {
                it.copy(
                    busy = true,
                    operationResult = null,
                    error = null,
                )
            }
            runCatching {
                mediaStore.createDeleteRequest(current.pendingDeletes.map(SessionItemEntity::uri))
            }.onSuccess { pendingIntent ->
                inFlightDeleteUris = current.pendingDeletes.map(SessionItemEntity::uri)
                inFlightFavoriteSaved = 0
                inFlightFavoriteFailures = 0
                _state.update { it.copy(awaitingSystemDelete = true) }
                eventChannel.send(CleaningEvent.LaunchDeleteAuthorization(pendingIntent))
            }.onFailure { error ->
                val result = BatchOperationResult(
                    deleteFailures = current.pendingDeletes.map {
                        DeleteFailure(it.uri, DeleteFailureReason.REQUEST_FAILED)
                    },
                    deleteAttempted = true,
                    requestFailed = true,
                )
                refresh(showBatchDialog = false, result = result)
                _state.update {
                    it.copy(error = error.message ?: "无法重试系统删除")
                }
            }
        }
    }

    fun retryFavorites() {
        val current = _state.value
        if (current.busy || current.pendingFavorites.isEmpty()) return
        confirmBatch(BatchSelection(favoriteSelected = true))
    }

    fun skipFailedDeletes() {
        val current = _state.value
        val session = current.session ?: return
        if (current.busy || current.pendingDeletes.isEmpty()) return
        viewModelScope.launch {
            _state.update { it.copy(busy = true, operationResult = null) }
            runCatching {
                repository.setDecisionPositions(
                    session.id,
                    current.pendingDeletes.map(SessionItemEntity::position),
                    SwipeDecision.FAILED_SKIPPED,
                )
            }.onSuccess {
                refresh(showBatchDialog = current.pendingFavorites.isNotEmpty())
            }.onFailure { error ->
                _state.update {
                    it.copy(busy = false, error = error.message ?: "无法跳过失败项目")
                }
            }
        }
    }

    fun returnToBatch() {
        _state.update { it.copy(operationResult = null) }
        viewModelScope.launch { refresh(showBatchDialog = false) }
    }

    fun continueAfterOperation() {
        _state.update { it.copy(operationResult = null) }
        viewModelScope.launch { refresh(showBatchDialog = true) }
    }

    fun dismissError() {
        _state.update { it.copy(error = null) }
    }

    private suspend fun refresh(
        showBatchDialog: Boolean,
        result: BatchOperationResult? = _state.value.operationResult,
    ) {
        val sessionId = _state.value.session?.id ?: return
        val snapshot = repository.snapshotOf(sessionId)
        if (snapshot == null) {
            _state.update {
                it.copy(
                    phase = CleaningPhase.ERROR,
                    busy = false,
                    error = "会话数据已丢失",
                )
            }
            return
        }
        renderSnapshot(snapshot, showBatchDialog, result)
    }

    private suspend fun renderSnapshot(
        initialSnapshot: SessionSnapshot,
        showBatchDialog: Boolean,
        result: BatchOperationResult? = null,
    ) {
        var snapshot = initialSnapshot
        if (snapshot.session.status == SessionStatus.ACTIVE &&
            SessionRules.isBatchBoundary(
                snapshot.session.currentIndex,
                snapshot.session.totalCount,
                snapshot.session.activeBatchStart,
            )
        ) {
            val pending = pendingItems(snapshot)
            if (pending.first.isEmpty() && pending.second.isEmpty()) {
                repository.finalizeBatch(snapshot.session.id)?.let { snapshot = it }
            }
        }

        val session = snapshot.session
        val pending = pendingItems(snapshot)
        val atBoundary = session.status == SessionStatus.ACTIVE &&
            SessionRules.isBatchBoundary(
                session.currentIndex,
                session.totalCount,
                session.activeBatchStart,
            )
        val currentIndex = if (atBoundary) {
            (session.currentIndex - 1).coerceAtLeast(0)
        } else {
            session.currentIndex
        }
        val currentItem = if (session.status == SessionStatus.COMPLETED) {
            null
        } else {
            snapshot.items.getOrNull(currentIndex)
        }
        val batchSize = SessionRules.batchSize(session.activeBatchStart, session.totalCount)
        val phase = when {
            session.status == SessionStatus.COMPLETED -> CleaningPhase.COMPLETED
            snapshot.items.isEmpty() -> CleaningPhase.EMPTY
            else -> CleaningPhase.READY
        }
        val canSwipe = phase == CleaningPhase.READY &&
            !atBoundary &&
            result == null
        val canUndo = phase == CleaningPhase.READY &&
            SessionRules.canUndo(
                reviewed = session.currentIndex,
                batchStart = session.activeBatchStart,
                batchLocked = session.batchLocked,
            )
        val hasPending = pending.first.isNotEmpty() || pending.second.isNotEmpty()
        _state.value = _state.value.copy(
            phase = phase,
            session = session,
            items = snapshot.items,
            currentItem = currentItem,
            total = session.totalCount,
            reviewed = session.currentIndex,
            activeBatchStart = session.activeBatchStart,
            currentBatchSize = batchSize,
            positionInBatch = if (atBoundary && batchSize > 0) {
                batchSize
            } else {
                SessionRules.displayPosition(session.currentIndex, session.activeBatchStart)
                    .coerceAtMost(batchSize.coerceAtLeast(1))
            },
            pendingDeletes = pending.first,
            pendingFavorites = pending.second,
            atBatchBoundary = atBoundary,
            canSwipe = canSwipe,
            canUndo = canUndo,
            batchDialogVisible = atBoundary && hasPending && showBatchDialog,
            discardDialogVisible = false,
            operationResult = result,
            busy = false,
            awaitingSystemDelete = false,
            stats = snapshot.stats,
            error = null,
        )
    }

    private fun pendingItems(snapshot: SessionSnapshot): Pair<List<SessionItemEntity>, List<SessionItemEntity>> {
        val inBatch = snapshot.items.filter {
            it.position >= snapshot.session.activeBatchStart &&
                it.position < snapshot.session.currentIndex
        }
        return inBatch.filter { it.decision == SwipeDecision.DELETE } to
            inBatch.filter { it.decision == SwipeDecision.FAVORITE }
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                CleaningViewModel(
                    repository = container.cleaningRepository,
                    mediaStore = container.mediaStore,
                )
            }
        }
    }
}
