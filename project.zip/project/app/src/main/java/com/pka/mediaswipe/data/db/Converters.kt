package com.pka.mediaswipe.data.db

import androidx.room.TypeConverter
import com.pka.mediaswipe.domain.SessionStatus
import com.pka.mediaswipe.domain.SwipeDecision

class Converters {
    @TypeConverter
    fun fromSwipeDecision(value: SwipeDecision): String = value.name

    @TypeConverter
    fun toSwipeDecision(value: String): SwipeDecision = SwipeDecision.valueOf(value)

    @TypeConverter
    fun fromSessionStatus(value: SessionStatus): String = value.name

    @TypeConverter
    fun toSessionStatus(value: String): SessionStatus = SessionStatus.valueOf(value)

}
