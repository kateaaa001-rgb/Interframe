package com.pka.mediaswipe.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.pka.mediaswipe.domain.FavoriteItem
import com.pka.mediaswipe.ui.components.AppBottomBar
import com.pka.mediaswipe.ui.components.EmptyState
import com.pka.mediaswipe.ui.components.MainDestination
import com.pka.mediaswipe.ui.components.MediaPreview
import com.pka.mediaswipe.ui.components.MediaThumbnail
import com.pka.mediaswipe.ui.viewmodel.FavoritesViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FavoritesScreen(
    viewModel: FavoritesViewModel,
    onNavigate: (MainDestination) -> Unit,
) {
    val state by viewModel.state.collectAsState()
    var selectedItem by remember { mutableStateOf<FavoriteItem?>(null) }
    var showInvalidCleanup by remember { mutableStateOf(false) }

    LaunchedEffect(state.loaded) {
        if (state.loaded) {
            viewModel.refreshValidity()
        }
    }

    if (showInvalidCleanup) {
        AlertDialog(
            onDismissRequest = { showInvalidCleanup = false },
            title = { Text("清理失效收藏记录？") },
            text = {
                Text("将从本地收藏清单移除 ${state.unavailableUris.size} 条无法访问的记录，不会改动系统相册文件。")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.removeAllUnavailable()
                        showInvalidCleanup = false
                    },
                ) { Text("清理记录") }
            },
            dismissButton = {
                TextButton(onClick = { showInvalidCleanup = false }) { Text("取消") }
            },
        )
    }

    selectedItem?.let { item ->
        FavoritePreviewDialog(
            item = item,
            unavailable = item.uri in state.unavailableUris,
            onDismiss = { selectedItem = null },
            onRemove = {
                viewModel.remove(item.uri)
                selectedItem = null
            },
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("本地收藏", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "${state.items.size} 项 · 仅保存在本机",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = viewModel::refreshValidity,
                        enabled = !state.checking,
                    ) {
                        if (state.checking) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp,
                            )
                        } else {
                            Icon(Icons.Filled.Refresh, contentDescription = "检查收藏有效性")
                        }
                    }
                },
            )
        },
        bottomBar = {
            AppBottomBar(selected = MainDestination.FAVORITES, onSelect = onNavigate)
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            if (state.unavailableUris.isNotEmpty()) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.74f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(10.dp),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            Icons.Filled.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.size(20.dp),
                        )
                        Text(
                            "${state.unavailableUris.size} 项收藏当前无法访问",
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 8.dp),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                        )
                        TextButton(onClick = { showInvalidCleanup = true }) {
                            Text("清理记录")
                        }
                    }
                }
            }

            when {
                !state.loaded -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                state.items.isEmpty() -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        EmptyState(
                            title = "还没有收藏",
                            detail = "在清理会话中右滑或点击“收藏”，并在批次确认后保存到这里。",
                        )
                    }
                }
                else -> {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(112.dp),
                        contentPadding = PaddingValues(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        items(state.items, key = { it.uri }) { item ->
                            FavoriteTile(
                                item = item,
                                unavailable = item.uri in state.unavailableUris,
                                onOpen = { selectedItem = item },
                                onRemove = { viewModel.remove(item.uri) },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FavoriteTile(
    item: FavoriteItem,
    unavailable: Boolean,
    onOpen: () -> Unit,
    onRemove: () -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(126.dp)
            .clip(RoundedCornerShape(9.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onOpen),
    ) {
        MediaThumbnail(
            uri = item.uri,
            isVideo = item.isVideo,
            contentDescription = item.displayName,
            modifier = Modifier.fillMaxSize(),
        )
        if (unavailable) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.58f)),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    "已失效",
                    color = Color.White,
                    style = MaterialTheme.typography.labelLarge,
                )
            }
        }
        IconButton(
            onClick = onRemove,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(4.dp)
                .size(30.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.50f)),
        ) {
            Icon(
                Icons.Filled.Delete,
                contentDescription = "从收藏中移除 ${item.displayName}",
                tint = Color.White,
                modifier = Modifier.size(17.dp),
            )
        }
        if (!unavailable) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.42f))
                    .padding(horizontal = 7.dp, vertical = 4.dp),
            ) {
                Text(
                    item.displayName,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
private fun FavoritePreviewDialog(
    item: FavoriteItem,
    unavailable: Boolean,
    onDismiss: () -> Unit,
    onRemove: () -> Unit,
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black),
        ) {
            if (unavailable) {
                Column(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(
                        Icons.Filled.Warning,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.75f),
                        modifier = Modifier.size(52.dp),
                    )
                    Text("收藏对应的媒体已无法访问", color = Color.White)
                    Text(
                        "可以清理这条失效记录。",
                        color = Color.White.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            } else {
                MediaPreview(
                    uri = item.uri,
                    isVideo = item.isVideo,
                    contentDescription = item.displayName,
                    modifier = Modifier.fillMaxSize(),
                )
            }

            Row(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                IconButton(
                    onClick = onRemove,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.50f)),
                ) {
                    Icon(
                        Icons.Filled.Delete,
                        contentDescription = "移除收藏记录",
                        tint = Color.White,
                    )
                }
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.50f)),
                ) {
                    Icon(Icons.Filled.Close, contentDescription = "关闭预览", tint = Color.White)
                }
            }

            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp),
                shape = RoundedCornerShape(12.dp),
                color = Color.Black.copy(alpha = 0.62f),
            ) {
                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp)) {
                    Text(
                        item.displayName,
                        color = Color.White,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                    )
                    Text(
                        if (item.isVideo) "本地视频" else "本地照片",
                        color = Color.White.copy(alpha = 0.72f),
                        style = MaterialTheme.typography.labelSmall,
                    )
                }
            }
        }
    }
}
