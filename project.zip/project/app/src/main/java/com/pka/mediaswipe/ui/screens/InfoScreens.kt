package com.pka.mediaswipe.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pka.mediaswipe.BuildConfig
import com.pka.mediaswipe.ui.components.ExternalLinkRow
import com.pka.mediaswipe.ui.components.SectionCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeveloperScreen(
    onBack: () -> Unit,
    onOpenPrivacy: () -> Unit,
) {
    InfoPageScaffold(title = "开发者信息", onBack = onBack) {
        item {
            SectionCard {
                Text(
                    BuildConfig.APP_NAME,
                    style = MaterialTheme.typography.headlineSmall,
                )
                Text(
                    "版本 ${BuildConfig.VERSION_NAME}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text("开发者：${BuildConfig.DEVELOPER_NAME}", style = MaterialTheme.typography.bodyMedium)
                Text("开发组织：${BuildConfig.ORGANIZATION_NAME}", style = MaterialTheme.typography.bodyMedium)
            }
        }
        item {
            SectionCard {
                Text("开发目的", style = MaterialTheme.typography.titleMedium)
                Text(
                    "帧间用刷视频的方式帮助用户在本地回看、整理照片和视频，" +
                        "通过分批标记与系统授权删除清理空间，并保留不复制原文件的收藏清单。",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Text(
                    "应用不提供账号、云同步、广告、遥测或媒体上传功能。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        item {
            SectionCard {
                Text("相关链接", style = MaterialTheme.typography.titleMedium)
                ExternalLinkRow("开发者个人博客", BuildConfig.BLOG_URL)
                ExternalLinkRow("开发组织官网", BuildConfig.ORGANIZATION_URL)
                ExternalLinkRow("app官网", BuildConfig.APP_SITE_URL)
                ExternalLinkRow("开源地址", BuildConfig.REPOSITORY_URL)
                OutlinedButton(onClick = onOpenPrivacy, modifier = Modifier.padding(top = 4.dp)) {
                    Text("查看隐私声明与免责声明")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    InfoPageScaffold(title = "隐私声明与免责声明", onBack = onBack) {
        item {
            SectionCard {
                Text("隐私声明", style = MaterialTheme.typography.titleLarge)
                Text(
                    "本应用用于帮助用户整理其设备上的照片与视频。应用仅访问用户授权范围内可读取的媒体，" +
                        "并在设备本地完成媒体浏览、收藏记录和清理操作。",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Text(
                    "应用未声明 INTERNET 权限，也不包含广告、行为分析、账号或遥测 SDK。" +
                        "照片、视频、URI、缩略图与文件内容不会由本应用发送到远程服务。",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Text(
                    "收藏清单、设置与必要的会话进度保存在设备本地 Room 数据库。" +
                        "应用关闭备份，不会通过 Android 系统备份机制主动复制这些数据。" +
                        "用户可以随时通过系统权限设置调整本应用的媒体访问权限。",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Text(
                    "相关外部链接只有用户主动点击时才会交给系统浏览器打开。应用本身不执行网络请求。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        item {
            SectionCard {
                Text("免责声明", style = MaterialTheme.typography.titleLarge)
                Text(
                    "删除操作具有风险。用户应在提交前仔细核对待删除项目。本应用在提交删除请求前提供确认流程，" +
                        "但不能保证已经删除的媒体可以恢复。",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Text(
                    "最终删除行为受 Android 系统授权机制、媒体提供方及设备实际状态影响。" +
                        "用户取消系统授权、媒体失效或部分操作失败时，应用不会将未成功删除的项目显示为已删除。",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Text(
                    "开发者不对用户主动确认删除后产生的数据损失承担超出适用法律允许范围的责任。" +
                        "建议在重要数据删除前使用设备云备份或其他可靠备份方案。",
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }
        item {
            SectionCard {
                Text("相关链接", style = MaterialTheme.typography.titleMedium)
                ExternalLinkRow("开发者个人博客", BuildConfig.BLOG_URL)
                ExternalLinkRow("开发组织官网", BuildConfig.ORGANIZATION_URL)
                ExternalLinkRow("用户协议", BuildConfig.TERMS_URL)
                ExternalLinkRow("隐私协议", BuildConfig.PRIVACY_URL)
                ExternalLinkRow("app官网", BuildConfig.APP_SITE_URL)
                ExternalLinkRow("开源地址", BuildConfig.REPOSITORY_URL)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun InfoPageScaffold(
    title: String,
    onBack: () -> Unit,
    content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            content = content,
        )
    }
}
