import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
    id("io.gitlab.arturbosch.detekt")
}

val appDisplayName = providers.gradleProperty("mediaswipe.appName").get()
val developerName = providers.gradleProperty("mediaswipe.developerName").get()
val organizationName = providers.gradleProperty("mediaswipe.organizationName").get()
val blogUrl = providers.gradleProperty("mediaswipe.blogUrl").get()
val organizationUrl = providers.gradleProperty("mediaswipe.organizationUrl").get()
val termsUrl = providers.gradleProperty("mediaswipe.termsUrl").get()
val privacyUrl = providers.gradleProperty("mediaswipe.privacyUrl").get()
val appSiteUrl = providers.gradleProperty("mediaswipe.appSiteUrl").get()
val repositoryUrl = providers.gradleProperty("mediaswipe.repositoryUrl").get()

fun quoted(value: String): String = "\"${value.replace("\\", "\\\\").replace("\"", "\\\"")}\""

android {
    namespace = "com.pka.mediaswipe"
    compileSdk = 36
    compileSdkMinor = 1

    defaultConfig {
        applicationId = "com.pka.mediaswipe"
        minSdk = 31
        targetSdk = 36
        versionCode = 9_010_710
        versionName = "beta_02"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables.useSupportLibrary = true

        buildConfigField("String", "APP_NAME", quoted(appDisplayName))
        buildConfigField("String", "DEVELOPER_NAME", quoted(developerName))
        buildConfigField("String", "ORGANIZATION_NAME", quoted(organizationName))
        buildConfigField("String", "BLOG_URL", quoted(blogUrl))
        buildConfigField("String", "ORGANIZATION_URL", quoted(organizationUrl))
        buildConfigField("String", "TERMS_URL", quoted(termsUrl))
        buildConfigField("String", "PRIVACY_URL", quoted(privacyUrl))
        buildConfigField("String", "APP_SITE_URL", quoted(appSiteUrl))
        buildConfigField("String", "REPOSITORY_URL", quoted(repositoryUrl))
        resValue("string", "app_name", appDisplayName)
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
        debug {
            applicationIdSuffix = ".debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources.excludes += setOf(
            "/META-INF/{AL2.0,LGPL2.1}",
            "/META-INF/LICENSE*",
            "/META-INF/NOTICE*",
        )
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

detekt {
    buildUponDefaultConfig = true
    config.setFrom(files("$rootDir/config/detekt/detekt.yml"))
    source.setFrom(
        files(
            "src/main/java",
            "src/test/java",
        ),
    )
    parallel = true
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2025.11.00")

    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.activity:activity-compose:1.11.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.4")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.4")
    implementation("androidx.navigation:navigation-compose:2.9.8")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")

    implementation("androidx.room:room-runtime:2.8.5")
    implementation("androidx.room:room-ktx:2.8.5")
    ksp("androidx.room:room-compiler:2.8.5")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    implementation("io.coil-kt.coil3:coil-compose:3.5.0")
    implementation("androidx.media3:media3-exoplayer:1.11.1")
    implementation("androidx.media3:media3-ui:1.11.1")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.10.2")

    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
